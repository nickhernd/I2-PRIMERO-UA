//SOLUCIONES BUCLES
#include <iostream>
using namespace std;

int main(){
	     
	 int n1, n2, prod, i;
	 float puntos;
	 char jugar;
	 
	 srand(time(NULL));		
	 jugar='s';
	
	 do{
	 	puntos=0;
	 	for (i=0; i<5; i++){
			 n1=rand()%10;
			 n2=rand()%10;
			 cout << n1 << "*" << n2 << "= ";
			 cin >> prod;
			 if (prod==n1*n2){
			   puntos++;
			   cout << "Acierto!\n";
			 }
			 else if (prod>n1*n2){			 	
				   cout << "Error!: LA SOLUCION ES MENOR\n";
				   cout << n1 << "*" << n2 << "= ";
			 		cin >> prod;
			 		if (prod==n1*n2){
						puntos=puntos+0.5;
						cout << "AHORA HAS ACERTADO!!\n";
					}
			 }
			 else {
			 		cout << "Error!: LA SOLUCION ES MAYOR\n";
			 		cout << n1 << "*" << n2 << "= ";
			 		cin >> prod;
			 		if (prod==n1*n2){
						puntos=puntos+0.5;
						cout << "AHORA HAS ACERTADO!!\n";
					}
			}
			 
		   
		}
		cout << "PUNTUACION: " << puntos << endl;
		cout << "Quieres jugar otra vez(s/n)? ";
		cin >> jugar;
	 }while (jugar=='s');
	    
	 
	 return 0;	 
}
