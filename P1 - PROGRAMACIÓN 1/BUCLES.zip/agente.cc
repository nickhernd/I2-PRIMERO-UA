//Programación 1
//Agente secreto

#include <iostream>
using namespace std;

int main(){
    int num, sumaCifras;
    
    
    cout << "N\u00FAmero: ";
    cin >> num;
    while (num>9){
        sumaCifras=0;
        while (num!=0){
            sumaCifras=sumaCifras+num%10;
            num=num/10;
        }
        num=sumaCifras;
    }
    
    cout << "N\u00FAmero decodificado: " << num << endl;
    
    return 0;
}


