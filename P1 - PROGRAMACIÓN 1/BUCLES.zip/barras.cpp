//SOLUCIONES BUCLES
#include <iostream>
using namespace std;

int main(){
	 int num, digControl, cifra, suma;
	 bool impar;
	 	 
    
	 cout << "Introduce el n�mero ";
	 cin >> num;
	 impar=true;
	 digControl=num%10;
	 num=num/10;
	 suma=0;
	 while (num!=0){
	 		 cifra=num%10;
	 		 num=num/10;
	 		 if (impar)
	 		 	 suma=suma+cifra*3;
		 	 else
		 	 	 suma=suma+cifra;
 	 	    impar = !impar;
	 }
	 
	 if ((suma+digControl)%10==0) 
	 	 cout << "SI";
	 else cout << "NO"; 
	 
	 return 0;	 
}
