//Programación 1
//dibujando figuras rellenas
#include <iostream>
#include "gfx.h"
using namespace std;

const int XSIZE=300;
const int YSIZE=300;

int main(){
    int i, op, lado1, lado2, origenX, origenY;
    char c;    
    
    gfx_open(XSIZE, YSIZE, "Dibujando cuadrados");
    gfx_color(0, 0, 255);
    
    cout << "1. Dibujar cuadrado\n";
    cout << "2. Dibujar rectángulo\n";
    cout << "¿Qué deseas dibujar? ";
    cin >> op;
    if (op==1){        
        cout << "¿Lado? ";
        cin >> lado1;        
        origenX=XSIZE/2-lado1/2;
        origenY=YSIZE/2-lado1/2;
        for (i=0; i< lado1; i++){
            gfx_line(origenX, origenY, origenX+lado1, origenY);
            origenY++;
        }     
    }
    else{
        cout << "¿Ancho? ";
        cin >> lado1;
        cout << "¿Alto? ";
        cin >> lado2;
        origenX=XSIZE/2-lado1/2;
        origenY=YSIZE/2-lado2/2;
        for (i=0; i< lado2; i++){
            gfx_line(origenX, origenY, origenX+lado1, origenY);
            origenY++;
        } 
    }
    c=gfx_wait(); 
    
    return 0;
}
    