//Programación 1
//Disparando proyectiles
#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include "gfx.h"

using namespace std;

const int XSIZE=300;
const int YSIZE=300;
const int YNAVE=20;
const int YARMA=270;
const int TAMBALA=5; //altura de la bala

int genPos(); 
void dibNave(int);
void dibBala(int, int);
void dibArma(int);


int main(){
    int xNave, xArma, xBala, yBala, veces, i;
    char c;
    
    srand(time(NULL));
    gfx_open(XSIZE,YSIZE,"Disparando proyectiles");	    
    
    //Genera las posiciones "x" de las distintas entidades
    //La posición de la bala se calcula en función del cañón
    xNave=genPos();
    xArma=genPos();    
    //Posición inicial de la bala
    xBala=xArma+4;
    yBala=YARMA-TAMBALA;    
    
    //Se usa para saber cuantas iteraciones tiene que hacer el bucle para ir desde
    // la y del cañón hasta la y de la nave
    veces=(YARMA-(YNAVE+20))/TAMBALA;
    i=0;  
    
    //Bucle para hacer avanzar la bala desde la posición del artefacto que dispara hacia arriba
    while (i<veces){
        gfx_clear();
        dibNave(xNave);        
        dibArma(xArma);   
        dibBala(xBala,yBala); 
        gfx_flush();
        usleep(50000); //retardo temporal        
        yBala=yBala-TAMBALA;
        i++;
    }
    
    if (xBala>=xNave && xBala<=xNave+20)
        cout << "Nave alcanzada\n";
    else
        cout << "Nave no alcanzada\n";
    
    c = gfx_wait(); 
    
    return 0;    
}

int genPos(){
    return rand()%277+2;
}

//Dibuja la nave como un cuadrado denso de tamaño 20 de color azul
void dibNave(int xNave){
    int i;
    
    gfx_color(0,0,255);
    for (i=YNAVE; i<YNAVE+20; i++)
        gfx_line(xNave, i, xNave+20, i);  
}

//Dibuja el cañon que dispara como un rectángulo hueco de 20x10 de color rosa
void dibArma(int xArma){
    
    gfx_color(255,0,255);
    gfx_line(xArma, YARMA, xArma+10, YARMA);
    gfx_line(xArma, YARMA+20, xArma+10, YARMA+20);
    gfx_line(xArma, YARMA, xArma, YARMA+20);
    gfx_line(xArma+10, YARMA, xArma+10, YARMA+20);
}

//Dibuja la bala como un rectángulo denso de TAMBALAx2 de color verde
void dibBala(int xBala, int yBala){
    int i;
    
    gfx_color(0,255,0);
    for (i=yBala; i<yBala+TAMBALA; i++)
        gfx_line(xBala, i, xBala+2, i);    
}