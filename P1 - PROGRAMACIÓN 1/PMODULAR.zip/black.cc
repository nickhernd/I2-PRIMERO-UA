//Programación 1
//BlackJack

#include <iostream>
#include <stdlib.h>
using namespace std;

int reparteCarta();
void calculaTotal(int &, int);
char quieres();
void bienvenida();

int main(){
    int carta, banca, puntos;
    char resp;
    
    srand(time(NULL));
    banca=rand()%21+1;
    puntos=0;
    bienvenida();
    do{  
        carta=reparteCarta();
        cout << "Te ha salido un " << carta << endl;
        calculaTotal(puntos, carta);
        cout << "Por ahora tienes " << puntos << ". ";
        if (puntos<21)
            resp=quieres();
    }while(resp=='s'&& puntos<21);
    cout << "\nLa banca tenía " << banca << endl;
    if (puntos>21)
        cout << "Te has pasado, ha ganado la banca\n";
    else if (21-banca < 21-puntos)
        cout << "Ha ganado la banca\n";
    else
        cout << "Has ganado\n";
    
    return 0;
}

//Muestra mensaje inicial
void bienvenida(){
    cout << "*************************************************************\n";
    cout << "* Bienvenido al BlackJack de Programación 1                 *\n";
    cout << "* Cada vez que pidas carta se sumarán los puntos obtenidos  *\n";
    cout << "* Recuerda no pasar de 21 si quieres ganar                  *\n";
    cout << "* ¡¡¡ BUENA SUERTE !!!                                      *\n";
    cout << "*************************************************************\n";
}
        
//Devuelve una carta generada al azar
int reparteCarta(){
    int c;
    
    c=rand()%12+1;
    
    return c;
}

//Pregunta al usuario si quiere otra carta
char quieres(){
    char resp;
    
    do{
        cout << "¿Quieres carta? (s/n)?"; 
        cin >> resp;
    }while (resp!='s' && resp!='n');
    
    return resp;
}

//Calcula los puntos totales con la carta que acaba de obtener el jugador
void calculaTotal(int &puntos, int carta){
    
    if (carta==1)
        puntos+=11;
    else if (carta>9)
        puntos+=10;
    else
        puntos+=carta;    
}




        
       