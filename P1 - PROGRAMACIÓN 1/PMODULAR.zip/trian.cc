//ProgramaciÃ³n 1
//Dibujando triÃ¡ngulos

#include <iostream>
using namespace std;

char menu();
void tri1(int, char, char, int &, int &);
void tri2(int, char, char, int &, int &);
void tri3(int, char, char, int &, int &);

char menu(){
    char op;
    
    do{
        cout << "1. Triángulo invertido izquierda\n";
        cout << "2. Triángulo invertido derecha\n";
        cout << "3. Triángulo equilatero\n";
        cout << "Opción: ";
        cin >> op;
    }while (op<'1' || op>'3');
    
    return op;
}

int main(){
    int n, numCar1, numCar2;
    char op, car1, car2;
    
    cout << "Número de filas: ";
    cin >> n;
    cout << "Caracteres para pintar: ";
    cin >> car1 >> car2;
    numCar1=0;
    numCar2=0;
    op=menu();
    if (op=='1')
        tri1(n, car1, car2, numCar1, numCar2);
    else if (op=='2')
        tri2(n, car1, car2, numCar1, numCar2);   
    else
        tri3(n, car1, car2, numCar1, numCar2);   
        
    cout << "Se han pintado " << numCar1 << " " << car1 << " y " << numCar2 << " " << car2 << endl;   
    
    return 0;
}

//Dibuja un triangulo invertido izquierda
void tri1(int tam, char c1, char c2, int &numCar1, int &numCar2){
    int i, j;
    
    for (i=1; i<=tam; i++){
        for (j=tam; j>=i; j--){
            if (i>1 && i<=tam-2 && j>i && j<tam){
                cout << c1;
                numCar1++;
            }
            else{
                cout << c2;
                numCar2++;
            }
        }
        cout << endl;
    }
    
}

//Dibuja un triangulo invertido derecha
void tri2(int tam, char c1, char c2, int &numCar1, int &numCar2){
     int i, j, k;
     
     for (i=1; i<=tam; i++){
        for (j=1; j<i; j++)
            cout << " ";
        for (k=tam; k>=i; k--){
            if ((i==1 && (k==tam || k==i)) || (i==tam)){
                cout << c1;
                numCar1++;
            }
            else{
                cout << c2;
                numCar2++;
            }
        }
        cout << endl;            
    }
}

//Dibuja un triangulo equilatero
void tri3(int tam, char c1, char c2, int &numCar1, int &numCar2){
    int i, j, k;
    
    for (i=1; i<=tam; i++){
        for (j=tam; j>i; j--)
            cout << " ";
        for (k=1; k<=2*i-1; k++){
            if (k%2){
                numCar1++;            
                cout << c1;
            }
            else{
                cout << c2;
                numCar2++;
            }
        }
        cout << endl;
    }
}
        
