//Programación 1
//Dibujando polígonos

#include <iostream>
#include "gfx.h"
#include <cmath>

using namespace std;

const int XSIZE=300;
const int YSIZE=300;
const float PI=3.14159;

int validaLados();
void validaCoordenadas(int &, int &, int &);

int main(){	
        int lados, radio;
        int xc, yc, i, xIni, yIni, xFin, yFin ;
        float angulo, anguloAcu;
       	char c;
	
	gfx_open(XSIZE,YSIZE,"Dibujando poligonos");	
	gfx_color(0,0,255);       
                
        validaCoordenadas(xc, yc, radio);
        lados=validaLados();        
        
        angulo=2*PI/lados;
        anguloAcu=0.0;
        xIni=xc+radio*cos(anguloAcu);
        yIni=yc+radio*sin(anguloAcu);
       
        for (i=0; i<lados; i++){
            anguloAcu=anguloAcu+angulo;
            xFin=xc+radio*cos(anguloAcu);
            yFin=yc+radio*sin(anguloAcu);
            gfx_line(xIni,yIni, xFin, yFin);            
            xIni=xFin;
            yIni=yFin;            
        }  
       
        c = gfx_wait();  

	return 0;
}

//Módulo para leer y validar las coordenadas
void validaCoordenadas(int &xC, int &yC, int &r){
    int i;
    bool ok;    
    
    do{
        ok=true;
        cout << "Introduce las coordenadas del centro (x,y) :";
        cin >> xC >> yC;
        cout << "Introduce el radio :";
        cin >> r;
        if (xC+r>=XSIZE || xC-r<=0 || yC+r>=YSIZE || yC-r<=0){
            cout << "Las coordenadas no son válidas\n";
            ok=false;
        }
    }while (!ok);
}
 
//Módulo para leer y validar el número de lados       
int validaLados(){
    int l;
    
    do{
       cout << "Introduce el número de lados :";
        cin >> l;
        if (l<4 || l>15)
            cout << "El número de lados debe estar entre 4 y 15\n";
    }while (l<4 || l>15);
    
    return l;
}
