//Programaci�n 1
//Los canarios del t�o Juan
#include <iostream>
#include <cstring>
#include <time.h>
#include <stdio.h>
using namespace std;

const int MAX=50; //NUMERO MAXIMO DE CANARIOS QUE PUEDE TENER EL TIO JUAN

typedef char TCadena[10]; 

struct TFecha{
    int dia;
    int mes;
    int anyo;
};

struct TMascota{    
    TCadena nombre;
    TFecha fec;
};

typedef TMascota TCanarios[MAX];

void iniciaCanarios(TCanarios, int &);
void alta (TCanarios, int &);
void listado (TCanarios, int);
void comprueba(TCanarios, int);
char menu();

int main(){
    TCanarios pajaros;
    int tam;
    char op;
	
    iniciaCanarios(pajaros, tam);
    do{
        op=menu();
	switch (op){
            case '1': alta (pajaros, tam);
                      break;
            case '2': comprueba (pajaros, tam);
                      break;
            case '3': listado(pajaros, tam);
                      break;
        }
    }while (op!='4');
        
    return 0;
}

//Muestra el men� del programa
char menu(){
    char op;
	
    do{
        cout << "1. DAR DE ALTA UN CANARIO" << endl;
        cout << "2. COMPROBAR VITAMINAS" << endl;
        cout << "3. LISTADO" << endl;
        cout << "4. SALIR" << endl;
        cout << "OPCION...";
        cin >> op;
        cout << "----------------------------" << endl;
    }while (op<'1' || op>'4');
	
    return (op);	
}

//Pide al usuario los datos de un canario
void alta (TCanarios pajaros, int &tam){
	
	
    cout << "NOMBRE DEL CANARIO...";
    cin >> pajaros[tam].nombre;
    cout << "FECHA DE ADQUISICION" << endl;
    cout << "\t DIA...";
    cin >> pajaros[tam].fec.dia;
    cout << "\t MES...";
    cin >> pajaros[tam].fec.mes;
    cout << "\t ANYO...";
    cin >> pajaros[tam].fec.anyo;
    tam++;
    cout << "--------------------------" << endl; 	
}

//Muestra los datos de todos los canarios
void listado (TCanarios pajaros, int tam){
	
    for (int i=0; i<tam; i++){
        cout << i+1 << ". " << pajaros[i].nombre << " " << pajaros[i].fec.dia << "-" << pajaros[i].fec.mes << "-" << pajaros[i].fec.anyo << endl;
    }
    cout << "--------------------------" << endl; 	
}

//Muestra los datos de los canarios a los que hay que dar vitaminas
void comprueba(TCanarios pajaros, int tam){	
    time_t t;
    struct tm *tlocal;   
    int dia, mes;

    t=time(NULL);
    tlocal=localtime(&t);
    dia=tlocal->tm_mday;
    mes=tlocal->tm_mon+1;    
          
    cout << "TOCA DAR VITAMINAS A: " << endl;
    for (int i=0; i<tam; i++){		
        if (pajaros[i].fec.dia==dia && pajaros[i].fec.mes==mes)
            cout << pajaros[i].nombre << endl;
    }
    cout << "-------------------------" << endl; 		
	
}

//Introduce los datos de los cuatro canarios iniciales
void iniciaCanarios(TCanarios pajaros, int &tam){
    strcpy(pajaros[0].nombre,"Piopio");
    pajaros[0].fec.dia=9;
    pajaros[0].fec.mes=3;
    pajaros[0].fec.anyo=2015;
	
    strcpy(pajaros[1].nombre,"Lina");
    pajaros[1].fec.dia=22;
    pajaros[1].fec.mes=12;
    pajaros[1].fec.anyo=2018;
	
    strcpy(pajaros[2].nombre,"Trompetilla");
    pajaros[2].fec.dia=5;
    pajaros[2].fec.mes=3;
    pajaros[2].fec.anyo=2017;
	
    strcpy(pajaros[3].nombre,"Bolita");
    pajaros[3].fec.dia=5;
    pajaros[3].fec.mes=3;
    pajaros[3].fec.anyo=2017;
    tam=4;
}
