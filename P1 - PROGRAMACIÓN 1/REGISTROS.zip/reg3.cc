//Programación 1
// Pescadores intrépidos
#include <iostream>
#include <cstring>
using namespace std;

const int MAX=50;

typedef char TCadena[10];

struct TPescador{
    TCadena nombre;
    int peces[40];
    int numPeces;
};

typedef TPescador TPescadores[MAX];

void alta(TPescadores, int &);
char menu();
void listado(TPescadores, int);
void perdedor(TPescadores, int);

int main(){
    TPescadores pescadores={{"Pole", {15, 4}, 2},
                            {"Vampi", {35}, 1},
                           };
    int n;
    char opcion;
    
    n=2;
    cout << "********************************************************\n";
    cout << "PESCADORES INTREPIDOS\n";
    cout << "********************************************************\n";
    do{
        opcion=menu();        
        switch (opcion){
            case '1': alta(pescadores, n);
                      break;
            case '2': listado(pescadores, n);
                      break;
            case '3': perdedor(pescadores, n);
                      break;
        }
    }while (opcion !='4');
    
    return 0;
}

//Muestra el menú
char menu(){
    char op;
    
    do{
        cout << "1. Dar de alta una captura\n";
        cout << "2. Listado de pescadores\n";
        cout << "3. Mostrar nombre del pescador\n";
        cout << "4. Salir\n";
        cout << "Opción: ";
        cin >> op;
    }while (op<'1' || op>'4');
    
    return op;
}

//Da de alta una captura
void alta(TPescadores pescadores, int &n){
    TCadena nombre;
    int posicion, i;
    
    cout << "********************************************************\n";
    cout << "ALTA DE CAPTURA\n";
    cout << "********************************************************\n";
    cout << "Nombre: ";
    cin >> nombre;
    //buscarlo en el vector
    i=0;
    while (strcmp(nombre, pescadores[i].nombre)!=0 && i<n)
        i++;
    if (i==n){ //el pescador no está dado de alta
        strcpy(pescadores[i].nombre, nombre);
        pescadores[i].numPeces=0;
        n++;
    }
    
    cout << "Longitud del pez: ";
    posicion=pescadores[i].numPeces;
    cin >> pescadores[i].peces[posicion];
    pescadores[i].numPeces++;
    cout << endl;
}

//Listado de pescadores con sus capturas
void listado(TPescadores pescadores, int n){
    int i, j;
    
    cout << "********************************************************\n";
    cout << "LISTADO\n";
    cout << "********************************************************\n";
    for (i=0; i<n; i++){
        cout << pescadores[i].nombre << " " << pescadores[i].numPeces << " capturas: ";
        for (j=0; j<pescadores[i].numPeces;j++)
            cout << pescadores[i].peces[j] << " ";
        cout << endl;
    }
    cout << endl;
}

//Muestra el pesacdor que ha pescado el pez más pequeño
void perdedor(TPescadores pescadores, int n){
    int i, j, posMin, min;
    
    posMin=0;    
    min=500;
    
    cout << "********************************************************\n";
    cout << "PESCADOR CON EL PEZ MAS PEQUEÑO\n";
    cout << "********************************************************\n";
    for (i=0; i<n; i++){
        for (j=0; j<pescadores[i].numPeces; j++){
            if (pescadores[i].peces[j]<min){
                min=pescadores[i].peces[j];
                posMin=i;                
            }
        }
    }
    
    cout << "El pez más pequeño lo ha pescado " << pescadores[posMin].nombre << endl << endl;
}     
    
    