//Programación 1
//Mercadillo
#include <iostream>
#include <string.h>

using namespace std;

const int MAX=100; 
const int MAXCAD=35;

typedef char TCadena[MAXCAD]; 

struct TObjeto{    
    TCadena nombre;    
    float precio;   
};  

typedef TObjeto TMercado[MAX];

char menu();
void alta(TMercado, int &);
void baja(TMercado, int &, float &);
void modif(TMercado, int);

int main(){
    TMercado objetos;
    int num;
    char op;
    float total;
    
    num=0;
    total=0.0;
    do{
        op=menu();
        switch (op) {
            case '1': alta(objetos, num);
                      break;
            case '2': baja(objetos, num, total);
                      break;
            case '3': modif(objetos, num);
                      break;
        }
    }while (op!='4');
    cout << "Se ha recaudado " << total << "euros\n";
    
    return 0;
}

char menu(){
    char op;
    
    do{
        cout << "\nMercadillo de Lucas\n";
        cout << "*********************\n";
        cout << "1. Alta de objeto\n";
        cout << "2. Baja de objeto\n";
        cout << "3. Modificación del precio de un objeto\n";
        cout << "4. Salir\n";
        cout << "¿Opción (1..4)? ";
        cin >> op;
    }while (op<'1' || op>'4');
    
    return op;
}

void alta(TMercado objetos, int &num){
    char resp;
    
    do{
        cin.get();
        cout << "Nombre del objeto ";
        cin.getline(objetos[num].nombre, MAXCAD);
        cout << "Precio: ";
        cin >> objetos[num].precio;
        num++;
        cout << "¿Quieres introducir otro objeto(s/n)? ";
        cin >> resp;
    }while (resp=='s' || resp=='S');
}

void baja(TMercado objetos, int &num, float &total){
    TCadena nombre;
    int i, j;
    char venta;
    
    
    cin.get();
    cout << "Nombre del objeto vendido: ";
    cin.getline(nombre, MAXCAD);
    i=0;
    while (i<num && strcmp(nombre, objetos[i].nombre)!=0)
        i++;
    if (i==num)
        cout << "Ese objeto no existe\n";
    else{
        cout << "Precio: " << objetos[i].precio << endl;
        cout << "Confirmar venta (s/n): ";
        cin >> venta;
        if (venta=='s' || venta=='S'){ //hay que darlo de baja
            total=total+objetos[i].precio;
            for(j=i; j<num-1; j++)
               objetos[j]=objetos[j+1];
            num--;
        }
    }
}
        

void modif(TMercado objetos, int num){
    TCadena nombre;
    int i;
    
    cin.get();
    cout << "Nombre del objeto a modificar: ";
    cin.getline(nombre, MAXCAD);
    i=0;
    while (i<num && strcmp(nombre, objetos[i].nombre)!=0)
        i++;
    if (i==num)
        cout << "Ese objeto no existe\n";
    else{
        cout << "Precio: " << objetos[i].precio << endl;
        cout << "Nuevo precio: ";
        cin >> objetos[i].precio;
        cout << "El precio se ha actualizado\n";        
    }
}        