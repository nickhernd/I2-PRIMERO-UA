//SOLUCIONES CONDICIONALES 3
#include <iostream>
using namespace std;

int main(){
	 int cO, cD;
	 	 
	 cout << "Introduce el despacho origen "; 
	 cin >> cO;
	 cout << "Introduce el despacho destino ";
	 cin >> cD;
	 if (cO<cD){
	 	 if (cD-cO < 60-cD+cO)
	 	 	 cout << cD-cO << " Creciente";
	 	 else
	 	    cout << 60-cD+cO << " Decreciente";
	 }
	 else{
	    if (cO-cD < 60-cO+cD)
	 	 	 cout << cO-cD << " Decreciente";
	 	 else
	 	    cout << 60-cO+cD << " Creciente";
	 }
	 system("pause");
	 
	 return 0;	 
}
