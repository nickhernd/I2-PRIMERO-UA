//Programación 1
//Números vampiro

#include <iostream>
using namespace std;

int main(){
    int num, c1, c2, c3, c4;
    
    cout << "Introduce un número: ";
    cin >> num;
    if (num>999 && num<10000){ //tiene 4 cifras
        c1=num/1000;
        c2=(num/100)%10;
        c3=(num/10)%10;
        c4=num%10;        
        if (c1==c4 && c2==c3 && c1%2==0 && c2%2==0 && c3%2==0 && c4%2==0 && c1==2*c2)
            cout << num << " es un número vampiro\n";
        else
            cout << num << " no es un número vampiro\n";
    }
    else
        cout << num << " no es un número vampiro\n";
    
    return 0;
}