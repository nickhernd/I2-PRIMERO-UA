//Programación 1
//dibujando figuras
#include <iostream>
#include "gfx.h"
using namespace std;

const int XSIZE=300;
const int YSIZE=300;

int main(){
    int op, lado1, lado2, origenX, origenY;
    char c;    
    
    gfx_open(XSIZE, YSIZE, "Dibujando cuadrados");
    gfx_color(0, 0, 255);
    
    cout << "1. Dibujar cuadrado\n";
    cout << "2. Dibujar rectángulo\n";
    cout << "¿Qué deseas dibujar? ";
    cin >> op;
    if (op==1){        
        cout << "¿Lado? ";
        cin >> lado1;        
        origenX=XSIZE/2-lado1/2;
        origenY=YSIZE/2-lado1/2;
        gfx_line(origenX, origenY, origenX+lado1, origenY);
        gfx_line(origenX+lado1, origenY, origenX+lado1, origenY+lado1);
        gfx_line(origenX+lado1, origenY+lado1, origenX, origenY+lado1);
        gfx_line(origenX, origenY+lado1, origenX, origenY);
        c=gfx_wait();        
    }
    else{
        cout << "¿Ancho? ";
        cin >> lado1;
        cout << "¿Alto? ";
        cin >> lado2;
        origenX=XSIZE/2-lado1/2;
        origenY=YSIZE/2-lado2/2;
        gfx_line(origenX, origenY, origenX+lado1, origenY);
        gfx_line(origenX+lado1, origenY, origenX+lado1, origenY+lado2);
        gfx_line(origenX+lado1, origenY+lado2, origenX, origenY+lado2);
        gfx_line(origenX, origenY+lado2, origenX, origenY);
        c=gfx_wait();
    }
    
    return 0;
}
    