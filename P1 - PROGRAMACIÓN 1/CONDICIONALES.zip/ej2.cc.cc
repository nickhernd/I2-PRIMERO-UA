//Programaci�n 1
// La biblioteca

#include <iostream>
using namespace std;

const int OCIO=50;
const int BAS=80;
const int EXT=60;

int main(){
	char tipo, tipoTr;
	int dias, cantidad;
	
	cantidad=-1;
	cout << "RECARGOS A APLICAR\n";
	cout << "\tOcio\t50 c\u00E9ntimos\n";
	cout << "\tB�sico\t80 c\u00E9ntimos\n";
	cout << "\tExtra\t60 c\u00E9ntimos\n";
	cout << "Tipo de material (o/t): ";
	cin >> tipo;
	if (tipo=='o' || tipo=='O')
		cantidad=OCIO;
	else if (tipo=='t' || tipo=='T'){
		cout << "B\u00E1sico o extra (b/e): ";
		cin >> tipoTr;
		cout << "N�mero de d\u00EDas de retraso: ";
		cin >> dias;
		if (tipoTr=='b' || tipoTr=='B'){
			cantidad=BAS*dias;
		}
		else if (tipoTr=='e' || tipoTr=='E'){
			cantidad=EXT*dias;
		}
		else
			cout << "Error: no existe ese tipo de material de trabajo";
	}
	else
		cout << "Error: no existe ese tipo de material";
		
	if (cantidad>=100)
		cout << "Hay que pagar " << cantidad/100 << " euros y " << cantidad%100 << " c\u00E9ntimos\n";
	else if (cantidad!=-1)
		cout << "Hay que pagar " << cantidad << " c\u00E9ntimos";
			
	return 0;	
}


