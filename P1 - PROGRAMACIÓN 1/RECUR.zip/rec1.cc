//Programación 1
//Suma dígitos

#include <iostream>
using namespace std;

int sumDig(int);


int main(){
    int num, res;
    
    cout << "Introduce un número: ";
    cin >> num;
    
    res=sumDig(num);
    cout << " = " << res << endl;
    
    return 0;
}

int sumDig(int n){
    int res;
    
    if (n<9){
        cout << n%10;
        res=n;
    }
    else{        
        res=n%10+sumDig(n/10);
        cout << " + " << n%10;
    }
    
    return res;
}