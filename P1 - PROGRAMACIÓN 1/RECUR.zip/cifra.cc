//Programación 1
//Mostrando la cifra i-ésima
#include <iostream>
#include <math.h>
using namespace std;

int cifra (int, int);

int main(){
    int num, pos;    
    
    do{
        cout << "Introduce un número ";
        cin >> num;
        cout << "Introduce la posición: ";
        cin >> pos;
        /* La posicion no es válida si es negativa o 
        mayor que el número de cifras que tiene el número */
        if (pos<0 || num/pow(10,pos)<1)
            cout << "La posición no es válida\n";
    }while (pos<0 || num/pow(10,pos)<1);
    cout << "La cifra es " << cifra (num, pos) << endl;
    
    return 0;
}

int cifra (int num, int pos){
    int val;
    
    if (pos==0)
        val=num%10;
    else 
        val=cifra(num/10, pos-1);
    
    return val;
}
        
    