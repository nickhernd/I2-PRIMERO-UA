//Programación 1
//Números capicua

#include <iostream>
#include <cmath>
using namespace std;

int pideNum();
bool capicua(int, int);
int cifras(int);


int main(){
    int n, cif, totalN, totalCap;
    
    totalN=0;
    totalCap=0;
    do{
        n=pideNum();        
        if (n!=0){
            totalN++;
            cif=cifras(n); 
            if (capicua(n, cif)== true){
                cout << n << " es capicua\n";
                totalCap++;
            }
            else
                cout << n << " no es capicua\n";
        }
    }while (n!=0);
    cout << "Total números introducidos: " << totalN << endl;
    cout << "Total números capicua: " << totalCap << endl;
    
    return 0;
}

//Pide un número y se asegura que sea mayor o igual que 0
int pideNum(){
    int n;
    
    do{
        cout << "Introduce un número: ";
        cin >> n;
        if (n<0)
            cout << "El número debe ser >=0\n";
    }while (n<0);
    
    return n;
}
    
    
//Determina si un número es capicua
bool capicua(int n, int cifras){
    bool res=true;
    int prim, ult;    
    
    if (cifras>1){
        prim=int(n/pow(10, cifras-1));
        ult=n%10;        
        if (prim==ult){
            res=capicua((n-prim*pow(10,cifras-1))/10, cifras-2);
        }
        else
            res=false;
    }
    
    return res;
}

//cuenta las cifras de un número
int cifras (int n){
    int c;
    
    if (n<10)
        c=1;
    else
        c=1+cifras(n/10);
    
    return c;
}