#include <iostream>
#include <vector>
#include <cstring>

using namespace std;

const int KNAME = 40;
const int KMAXOBSTACLES = 20;
const int KMAXLEVELS = 10;

enum Error{
    ERR_OPTION,
    ERR_DIFFICULTY,
    ERR_LEVEL,
    ERR_COORDINATE,
    ERR_OBSTACLES,
    ERR_ID,
    ERR_INSTRUCTION
};

// Registro para las coordenadas
struct Coordinate{
    int row;
    int column;
};

// Registro para el jugador
struct Player{
    char name[KNAME];
    int difficulty;
    int score;
    int wins;
    int losses;
};

// Registro para el nivel
struct Level{
    int id;
    int size;
    int numObstacles;
    Coordinate obstacles[KMAXOBSTACLES];
    Coordinate start;
    Coordinate finish;
};

// Función que muestra los mensajes de error
void error(Error e){
    switch(e){
        case ERR_OPTION: cout << "ERROR: wrong option" << endl;
            break;
        case ERR_DIFFICULTY: cout << "ERROR: wrong difficulty" << endl;
            break;
        case ERR_LEVEL: cout << "ERROR: cannot create level" << endl;
            break;
        case ERR_COORDINATE: cout << "ERROR: wrong coordinate" << endl;
            break;
        case ERR_OBSTACLES: cout << "ERROR: wrong number of obstacles" << endl;
            break;
        case ERR_ID: cout << "ERROR: wrong id" << endl;
            break;
        case ERR_INSTRUCTION: cout << "ERROR: wrong instruction" << endl;
            break;
    }
}

// Función que muestra el menú de opciones
void showMenu(){
    cout << "[Options]" << endl
        << "1- Create level" << endl
        << "2- Delete level" << endl
        << "3- Show levels" << endl
        << "4- Play" << endl
        << "5- Report" << endl
        << "q- Quit" << endl
        << "Option: ";
}

void readPlayer(Player &player){
	cout << "Name: ";
	cin.getline(player.name, KNAME);
	do{
		cout << "Difficulty: ";
		cin >> player.difficulty;
		cin.get();
		if(player.difficulty < 1 || player.difficulty > 3){
			error(ERR_DIFFICULTY);	
		}
	}while(player.difficulty < 1 || player.difficulty > 3);
	player.losses = 0;
	player.wins = 0;
	player.score = 0;
}

void report(Player player){
	cout << "[Report]" << endl;
	cout << "Name: " << player.name << endl;
	cout << "Difficulty: ";
	switch(player.difficulty){
		case 1:
			cout << "Easy" << endl;
			break;
		case 2:
			cout << "Medium" << endl;
			break;
		case 3:
			cout << "Hard" << endl;
			break;
	}
	cout << "Score: " << player.score << endl;
	cout << "Wins: " << player.wins << endl;
	cout << "Losses: " << player.losses << endl;
	cout << "Total: " << player.wins + player.losses << endl;
}

bool iguales(Coordinate c1, Coordinate c2){
	return c1.row == c2.row && c1.column == c2.column;
}

bool buscarCoordenada(Coordinate obstacles[], int numObstacles, Coordinate cor){
	bool encontrado = false;
	for(int k = 0; k < numObstacles && !encontrado; k++){
		if(iguales(obstacles[k], cor) == true){
			encontrado = true;
		}
	}
	return encontrado;
}

bool searchAdyaccent(Coordinate obstacles[], int numObstacles, Coordinate cor){
	bool encontrada = false;
	
	for(int k = 0; k < numObstacles && encontrada == false; k++){
		if(abs(obstacles[k].row - cor.row) <= 1 && abs(obstacles[k].column - cor.column) <= 1){
			encontrada = true;
		}
	}
	return encontrada;
}

void showLevel(Level level){
	bool encontrado;
	for(int i = 0; i < level.size; i++){
		for(int j = 0; j <(int) level.size; j++){
			if(iguales(level.start, {i, j}){
				cout << "R";
			}
			else{
				if(iguales(level.finish, {i, j}){
					cout << "F";
				}
				else{
					Coordinate actual = {i, j};
					encontrado = buscarCoordenada(level.obstacles, level.numObstacles, actual);
					if(encontrado == true){
						cout << "X";
					}
					else{
						cout << "O";
					}
				}
			}
		}
		cout << endl;
	}
}

void readObstacles(Level &nuevo, int maximo){
	int i;
	char linea[100];
	bool err;
	Coordinate cor;

	do{
		err = false;
		cout << "Obstacles: ";
		cin.getline(linea, 100);
	
		/*string juankiNOtranki;
		getline(cin, juankiNOtranki);*/

		nuevo.numObstacles = 0;
		i = 0;
		while(i < (int) strlen(linea) && err == false){
			cor.row = linea[i] - '0';
			cor.column = linea[i + 2] - '0';
			i = i + 4;
			if(nuevo.numObstacles == maximo){	// si he llegado al maximo
				err = true;
				error(ERR_OBSTACLES);
			}
			else{
				if(cor.row >= nuevo.size || cor.column >= nuevo.size){ // si me he salido del tablero.
					err = true;
					error(ERR_COORDINATE);			
				}
				else{
					
					if(iguales(nuevo.start, cor) || iguales(nuevo.finish, cor)){
						error(ERR_COORDINATE);
						err = true;
					}
					else{
						err = searchAdyaccent(nuevo.obstacles, nuevo.numObstacles, cor);	// si es adyacente o coincidente
						if(err){
							error(ERR_COORDINATE);
						}
						else{
							nuevo.obstacles[nuevo.numObstacles++] = cor;
						}
					}
				}
			}
		}
	}while(err == true);
}
		

void createLevel(vector<Level> &levels, int &nextId, int d){
	Level nuevo;
	int maximo;

	if(levels.size() == KMAXLEVELS){
		error(ERR_LEVEL);
	}
	else{
		nuevo.id = nextId;
		nextId++;
		switch(d){
			case 1: nuevo.size = 5; maximo = 5; break;
			case 2: nuevo.size = 7; maximo = 10; break;
			case 3: nuevo.size = 10; maximo = 20; break;
		}
		nuevo.start = {nuevo.size - 1, 0};
		nuevo.finish = {0, nuevo.size - 1};
		readObstacles(nuevo, maximo);		
		levels.push_back(nuevo);
		cout << "Level " << nuevo.id << endl;
		showLevel(nuevo);
	}
}


void showLevels(vector<Level> levels){
	for(int i = 0;i < (int) levels.size(); i++){
		cout << "Level " << levels[i].id << endl;
		showLevel(levels[i]);
	}
}

// -1 si no lo encuentro
int buscarLevel(vector<Level> levels, int id){
	int i, pos;
	pos = -1;
	for(i = 0; i < (int) levels.size() && pos == -1; i++){
		if(id == levels[i].id){
			pos = i;
		}
	}
	return pos;
}

char preguntar(){
	char r;
	do{
		cout << "Are you sure? [y/n] ";
		cin >> r;
		cin.get();
	}while(r != 'y' && r != 'Y' && r != 'n' && r != 'N');
	return r;
}

void deleteLevel(vector<Level> &levels){
	int id, pos;
	char respuesta;

	cout << "Id: ";
	cin >> id;
	cin.get();
	pos = buscarLevel(levels, id);
	if(pos == -1){
		error(ERR_ID);
	}
	else{
		respuesta = preguntar();
		if(respuesta == 'y' || respuesta == 'Y'){
			levels.erase(levels.begin() + pos);
		}
	}
}
bool mover(Coordinate &start, char mander){
	bool err = false;
	switch(mander){
		case 'L':
			start.column--;
		break;
		case 'R':
			start.column++;
		break;
		case 'U':
			start.row--;
		break;
		case 'D':
			start.row++;
		break;
		default:
			err = true;
			error(ERR_INSTRUCTION);
		break;
	}
	return err;
}

bool fuera(Coordinate start, int size){
	return start.column < 0 || start.column >= size || start.row < 0 || start.row >= size;
}

void playLevel(Player &player, vector<Level> levels){
	int id, pos, i, points;
	char linea[100];
	Level juego;
	bool err, isObstacle;	

	cout << "Id: ";
	cin >> id;
	cin.get();
	pos = buscarLevel(levels, id);
	if(pos == -1){
		error(ERR_ID);
	}
	else{
		err = false;
		juego = levels[pos];	
		cout << "Level " << juego.id << endl;
		showLevel(juego);
		cout << "Instructions: ";
		cin.getline(linea, 100);
		for(i = 0; linea[i] != '\0' && err == false; i++){
			err = mover(juego.start, linea[i]); // instruccion correcta y muevo.
			if(!err){
				if(fuera(juego.start, juego.size) == true){
					error(ERR_INSTRUCTION);
					err = true;				
				}
				else{
					isObstacle = buscarCoordenada(juego.obstacles, juego.numObstacles, juego.start);		
					if(isObstacle){
						error(ERR_INSTRUCTION);
						err = true;
					}
					else{
						cout << "Instruction " << linea[i] << endl;
						showLevel(juego);
					}
				}
			}
			
		}
		if(err == true){
			cout << "You lose" << endl;
			player.losses++;
		}
		else{
			if(iguales(juego.start, juego.finish) == true){
				points = 3 * (juego.size - 1) - strlen(linea);
				cout << "You win " << points << " points" << endl;
				player.score += points;
				player.wins++;
			}
			else{
				cout << "You lose" << endl;
				player.losses++;
			}
		}
	
	}
}


// Función principal (tendrás que añadirle más código tuyo)
int main(){
    char option;
	Player player;  
	vector<Level> levels;
	int nextId;

	nextId = 1;
	readPlayer(player);
    do{
        showMenu();
        cin >> option;
        cin.get(); // Para evitar que el salto de línea se quede en el buffer de teclado y luego pueda dar problemas si usas "getline"
        
        switch(option){
            case '1': // Llamar a la función para crear un nuevo nivel
				createLevel(levels, nextId, player.difficulty);                
				break;
            case '2': // Llamar a la función para borrar un nivel existente
				deleteLevel(levels);
                break;
            case '3': // Llamar a la función para mostrar los niveles creados
				showLevels(levels);
                break;
            case '4': // Llamar a la función para jugar
				playLevel(player, levels);
                break;
            case '5': // Llamar a la función para mostrar información del jugador
				report(player); 
               break;
            case 'q': break;
            default: error(ERR_OPTION); // Muestra "ERROR: wrong option"
        }
    }while(option!='q');
}
