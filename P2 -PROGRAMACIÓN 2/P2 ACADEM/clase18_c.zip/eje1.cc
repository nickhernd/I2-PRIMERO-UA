#include <iostream>
using namespace std;

class Coord{
	public:
		int x, y;
};


int main(){
	Coord c1;
	Coord c2 = {12, 32};
	Coord c3 = {90, 12};
	Coord c4;

	c1.x = 0;
	c1.y = 0;
	cout << c1.x << ", " << c1.y << endl;
	cout << c2.x << ", " << c2.y << endl;
	cout << c3.x << ", " << c3.y << endl;
	cout << c4.x << ", " << c4.y << endl;

	return 0;
}
