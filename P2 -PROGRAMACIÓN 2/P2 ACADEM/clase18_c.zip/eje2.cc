#include <iostream>
using namespace std;

class Coord{
	public:
		int x, y;
		// Metodos constructores:
		//	- Se llaman igual que la clase que los contienen.
		//	- No devuelven nada ni siquiera void.
		// 	- Se pueden sobrecargar, es decir, podemos definir
		// 	varios constructores siempre que cambiemos el tipo
		// 	numero/tipo u orden.
		// 	- Sirven para inicializar los nuevos objetos, variables
		// 	de tipo class.
		//	- Reciben de forma implicita el objeto que se esta
		// inicializando
		Coord(){
			x = 0;
			y = 0;
		}
		Coord(int vx, int vy){
			x = vx;
			y = vy;
		}
};

int main(){
	// si no ponemos parametros, se invoca al constructor sin parametros
	// o constructor por defecto.
	Coord c0;	// x = 0; y = 0;
	Coord c1;	// x = 0; y = 0;
	Coord c2(23, 14);	// vx = 23; vy = 14
				// x = 23
				// y = 14
	Coord c3(34, 12);	// vx = 34; vy = 12
				// x = 34
				// y = 12

	cout << c0.x << ", " << c0.y << endl; // 0, 0
	cout << c1.x << ", " << c1.y << endl; // 0, 0
	cout << c2.x << ", " << c2.y << endl; // 23, 14
	cout << c3.x << ", " << c3.y << endl; // 34, 12

	return 0;
}
