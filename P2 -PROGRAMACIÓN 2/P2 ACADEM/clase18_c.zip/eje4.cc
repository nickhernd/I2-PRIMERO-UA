#include <iostream>
using namespace std;

class Natural{
	private:
		int valor;
	public:
		// metodos constructores
		Natural(){
			valor = 0;
		}
		Natural(int v){
			if(v < 0){
				valor = 0;
			}
			else{
				valor = v;
			}
		}
	
		// metodos de instancia: todos los metodos de instancia
		// reciben de forma implicita el objeto que los invoca.
		int getValor(){
			return valor;
		}
		void setValor(int v){
			if(v >= 0){
				valor = v;
			}
		}
};

int main(){
	Natural n1(32);
	Natural n2(-34);
	
	// n1.valor = -2;
	// cout << n1.valor << endl;
	
	cout << n1.getValor() << endl; // return n1.valor
	cout << n2.getValor() << endl; // return n2.valor
	n1.setValor(14);	// v = 14
				// valor = 14 (de n1)

	n2.setValor(-34);	// v = -34
				
	cout << n1.getValor() << endl;
	cout << n2.getValor() << endl;
	



	return 0;
}
