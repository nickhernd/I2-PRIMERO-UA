#include <iostream>
using namespace std;

class Natural{
	public:
		int valor;
		Natural(){
			valor = 0;
		}
		Natural(int v){
			if(v < 0){
				valor = 0;
			}
			else{
				valor = v;
			}
		}
};

int main(){
	Natural n1;		// n1.valor = 0
	Natural n2;		// n2.valor = 0
	Natural n3(12);		// n3.valor = 12
	Natural n4(-43);	// n4.valor = 0

	cout << n1.valor << endl;
	cout << n2.valor << endl;
	cout << n3.valor << endl;
	cout << n4.valor << endl;
	// :)

	n1.valor = -12;
	cout << n1.valor << endl;
	return 0;
}
