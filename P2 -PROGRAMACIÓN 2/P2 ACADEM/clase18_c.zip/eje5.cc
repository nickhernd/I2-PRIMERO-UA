#include <iostream>
using namespace std;

class Hora{
	private:
		int horas, minutos;
	public:
		Hora(){
			horas = 0;
			minutos = 0;
		}
		Hora(int vh, int vm){
			if(vh < 0 || vh > 23 || vm < 0 ||  vm > 59){
				horas = 0;
				minutos = 0;
			}
			else{
				horas = vh;
				minutos = vm;
			}
		}
		// metodo constante: no modifica el objeto que lo invoca
		int getHoras() const{
			return horas;
		}
		int getMinutos() const{
			return minutos;
		}
		void setHoras(int vh){
			if(vh >= 0){
				horas = vh;
			}
		}
		void setMinutos(int vm){
			if(vm >= 0){
				minutos = vm;
			}
		}
		// incrementa la hora en una hora, devuelve cierto
		// si cambia de dia.
		bool incHora(){
			// horas minutos		
			bool cambio = false;
			if(horas != 23){
				horas++;
			}
			else{
				horas = 0;
				cambio = true;			
			}
			return cambio;
		}
		
		void imprimir() const{
			if(horas < 10){
				cout << "0";
			}
			cout << horas << ":";
			if(minutos < 10){
				cout << "0";
			}
			cout << minutos;
		}

		// incrementa en un minuto la hora, devuelve cierto
		// si cambia de dia.
		bool incMinuto(){
			bool cambio = false;
			if(minutos != 59){
				minutos++;
			}
			else{
				minutos = 0;
				if(horas == 23){
					horas = 0;
					cambio = true;
				}
				else{
					horas++;
				}
			}

			return cambio;
		}		
	/*
			- si min es positivo incrementa la hora implicita
			en los minutos min pasados como parametros.
			- devuelve el numero de veces quese ha cambiado de dia.
		*/
		int incMinutos(int min){
			int dias = 0;
			for(int i = 1; i <= min; i++){
				if(incMinuto()){
					dias++;
				}
			}
			return dias;
		}
};

int main(){
	Hora entrada(12, 49);

	int dias = entrada.incMinutos(45020);

	cout << "Han pasado dias " << dias << endl;
	entrada.imprimir();
	cout << endl;

	Hora salida(14, 59);
	salida.incMinuto();
	salida.imprimir();
	cout << endl;
	Hora mi(12, 32);
	mi.incHora();
	cout << mi.getHoras() << endl; // 13

	Hora h1(12, 32);	// vh = 12
				// vm = 32
				// horas = 12
				// minutos = 32

	Hora h2(-34, 23);	// vh = -34
				// vm = 23
				// horas = 0
				// minutos = 0


	cout << h1.getHoras() << ":" << h1.getMinutos() << endl;
	cout << h2.getHoras() << ":" << h2.getMinutos() << endl;
	return 0;
}

