#include <iostream>
using namespace std;

namespace game{
	void f(){
		cout << "holi game" << endl;
	}
}


namespace box{
	void f(){
		cout << "holi box" << endl;
	}
}

int main(){
	game::f();
	box::f();
	std::cout << "holi" << endl;
	std::string nombre = "jose manuel";
	
	return 0;
}
