#include <iostream>
#include <vector>
#include <cstdlib>
using namespace std;

int main(){
	vector<int> enteros;

	// rellenarlo con 10 valores aleatorios entre 1 y 10.
	for(int i = 1; i <= 10; i++){
		enteros.push_back(rand() % 10 + 1);
	}

	// imprimir un vector
	for(int i = 0; i < enteros.size(); i++){
		cout << enteros[i] << " ";
	}
	cout << endl;

	// pedid un valor y mostrad las posiciones donde aparece
	// dicho valor.
	int buscado;
	cout << "Introduce el valor a buscar: ";
	cin >> buscado;
	for(int i = 0; i < enteros.size(); i++){
		if(enteros[i] == buscado){
			cout << i << endl;
		}
	}

	// pedid un valor y mostrad la primera posicion donde
	// aparece o "NO ESTA" si el valor no esta en el vector.
	cout << "Introduce el valor a buscar: ";
	cin >> buscado;
	int pos = -1;
	for(int i = 0; i < enteros.size() && pos == -1; i++){
		if(enteros[i] == buscado){
			pos = i;
		}
	}
	if(pos == -1){
		cout << "NO ESTA" << endl;
	}
	else{
		cout << "encontrado en posicion " << pos << endl;
	}
	

}
