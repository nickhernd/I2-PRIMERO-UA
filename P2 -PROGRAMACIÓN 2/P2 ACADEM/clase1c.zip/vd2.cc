#include <iostream>
#include <vector>
using namespace std;


void imprimir(vector<int> enteros){
	for(int i = 0; i < enteros.size(); i++){
		cout << enteros[i] << " ";
	}
	cout << endl;
}

int main(){
	vector<int> enteros = {22, 44, 56, 8, 10, 68};

	imprimir(enteros);

	enteros.erase(enteros.begin());
	imprimir(enteros);

	enteros.erase(enteros.begin() + 3);
	imprimir(enteros);
	
	
	enteros.insert(enteros.begin(), 55);
	imprimir(enteros);

	enteros.insert(enteros.begin() + 2, 10);
	imprimir(enteros);
	

	enteros[0] = 10000;
	imprimir(enteros);
	

	return 0;
}
