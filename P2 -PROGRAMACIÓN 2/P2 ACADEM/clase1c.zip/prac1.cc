#include <iostream>

using namespace std;

const int KNAME=40;
const int KMAXOBSTACLES=20;
const int KMAXLEVELS=20;

enum Error{
    ERR_OPTION,
    ERR_DIFFICULTY,
    ERR_LEVEL,
    ERR_COORDINATE,
    ERR_OBSTACLES,
    ERR_ID,
    ERR_INSTRUCTION
};

// Registro para las coordenadas
struct Coordinate{
    int row;
    int column;
};

// Registro para el jugador
struct Player{
    char name[KNAME];
    int difficulty;
    int score;
    int wins;
    int losses;
};

// Registro para el nivel
struct Level{
    int id;
    int size;
    int numObstacles;
    Coordinate obstacles[KMAXOBSTACLES];
    Coordinate start;
    Coordinate finish;
};

// Función que muestra los mensajes de error
void error(Error e){
    switch(e){
        case ERR_OPTION: cout << "ERROR: wrong option" << endl;
            break;
        case ERR_DIFFICULTY: cout << "ERROR: wrong difficulty" << endl;
            break;
        case ERR_LEVEL: cout << "ERROR: cannot create level" << endl;
            break;
        case ERR_COORDINATE: cout << "ERROR: wrong coordinate" << endl;
            break;
        case ERR_OBSTACLES: cout << "ERROR: wrong number of obstacles" << endl;
            break;
        case ERR_ID: cout << "ERROR: wrong id" << endl;
            break;
        case ERR_INSTRUCTION: cout << "ERROR: wrong instruction" << endl;
            break;
    }
}

// Función que muestra el menú de opciones
void showMenu(){
    cout << "[Options]" << endl
        << "1- Create level" << endl
        << "2- Delete level" << endl
        << "3- Show levels" << endl
        << "4- Play" << endl
        << "5- Report" << endl
        << "q- Quit" << endl
        << "Option: ";
}

// lo paso por referencia porque voy a modificar la variable dentro...
void initPlayer(Player &p){

}

Player getNewPlayer(){
	Player p;
	// ...
	p.score = 0;
	// ...
	return p;
}


void createLevel(vector<Level> &levels, int &nextId, Player p){
	Level newLevel;

	if(levels.size() == KMAXLEVELS){
		error(ERR_LEVEL);
	}
	else{
		// newLevel.id = levels.size() + 1;
		newLevel.id = nextId;
		nextId++;
		if(p.difficulty == 1){	
			newLevel.size = 5;
		}
		// TODO LETS GO... quizas un switch, quizas una funcion auxiliar...
		/*
		// TODO LEETE LA PRACTICA.		
		newLevel.start.row = 
		newLevel.start.column = 
		newLevel.finish.row = 
		newLevel.finish.column = 
		*/		
		// ...
		newLevel.numObstacles = 0;
	}
}

int buscarLevel(vector<Level> levels, int idLevel){
	int i, pos;
	i = 0;
	pos = -1;
	while(i < levels.size()  && pos == -1){
		if(levels[i].id == idLevel){
			pos = i;
		}
		else{
			i++;
		}
	}
	return pos;
}

void deleteLevel(vector<Level> &levels){
	int id, pos;

	cout << "Id: ";
	cin >> id;
	cin.get();

	// pos = buscarLevel(levels, id);
	pos = -1;
	for(int i = 0; i < levels.size() && pos == -1; i++){
		if(levels[i].id == id){
			pos = i;
		}
	}	
	if(pos == -1){
		error(ERR_ID);
	}
	else{
		levels.erase(levels.begin() + pos);
	}

}

void report(Player player){
	cout << "[Report]" << endl;
	cout << "Name: " << player.name << endl;
	// TODO... que salga easy y que no salga 1 2 3
	cout << "Difficulty: " << player.difficulty << endl;
	cout << "Score: " << player.score << endl;
	// TODO... el resto de campos
}

// Función principal (tendrás que añadirle más código tuyo)
int main(){
    char option;    
	Player player;
	int nextId = 1;
/*
	// Vintage = p1
	Level levels[20];
	int numLevels = 0;
*/
	vector<Level> levels;


	cout << "Name: ";
	cin.getline(player.name, KNAME);

	// TODO 1 En caso de que la dificultad no sea correcta
	// sacamos un mensaje de error y la volvemos a pedir 😅️
	cout << "Difficulty: ";
	cin >> player.difficulty;

	player.score = 0;
	player.wins = 0;
	player.losses = 0;

	// TODO 2 Metemos la inicializacion del player en una funcion
	// Opcion 1: initPlayer(player);
	// Opcion 2: player = getNewPlayer();

    do{
        showMenu();
        cin >> option;
        cin.get(); // Para evitar que el salto de línea se quede en el buffer de teclado y luego pueda dar problemas si usas "getline"
        
        switch(option){
            case '1': // Llamar a la función para crear un nuevo nivel
				createLevel(levels, nextId);
                break;
            case '2': // Llamar a la función para borrar un nivel existente
				deleteLevel(levels);                
				break;
            case '3': // Llamar a la función para mostrar los niveles creados
                break;
            case '4': // Llamar a la función para jugar
                break;
            case '5': // Llamar a la función para mostrar información del jugador
				report(player);                
				break;
            case 'q': break;
            default: error(ERR_OPTION); // Muestra "ERROR: wrong option"
        }
    }while(option!='q');
}
