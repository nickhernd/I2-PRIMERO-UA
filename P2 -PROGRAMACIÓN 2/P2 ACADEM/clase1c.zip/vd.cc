#include <iostream>
#include <vector>
using namespace std;

const int KMAXOBSTACLES=20;

struct Coordinate{
    int row;
    int column;
};

// Registro para el nivel
struct Level{
    int id;
    int size;
    int numObstacles;
    Coordinate obstacles[KMAXOBSTACLES];
    Coordinate start;
    Coordinate finish;
};

int main(){
	// vectores dinamicos inicialmente vacios.
	// entre <> pondremos el tipo de datos que hay en cada posicion
	// del vector.
	vector<int> enteros;
	vector<char> caracteres = {'a', 'b', 'c'};
	vector<bool> activados(5, true);
	vector<Coordinate> coordinates(10, {3, 4});
	vector<Level> levels;	

	cout << enteros.size() << endl;
	cout << caracteres.size() << endl;
	cout << activados.size() << endl;

	// enteros[0] = 3;
	// añade una posicion nueva a continuacion de las existentes
	// y COPIA el argumento en esa posicion,
	enteros.push_back(3);
	enteros.push_back(123);
	enteros.push_back(34);

	cout << "ahora tengo: " <<  enteros.size() << endl;
	for(int i = 0; i < enteros.size(); i++){
		cout << enteros[i] << endl;
	}
	
	cout << "En el vector de caracteres" << endl;
	caracteres.push_back('A');
	for(int i = 0; i < caracteres.size(); i++){
		cout << caracteres[i] << endl;
	}

	cout << "En el vector de coordenadas" << endl;
	for(int i = 0; i < coordinates.size(); i++){
		cout << coordinates[i].row << ", " << coordinates[i].column << endl;
	}
	cout << endl;

	// nueva coordenada!!
	Coordinate nueva;
	cout << "row: ";
	cin >> nueva.row;
	cout << "column: ";
	cin >> nueva.column;
	coordinates.push_back(nueva);

	cout << "En el vector de coordenadas" << endl;
	for(int i = 0; i < coordinates.size(); i++){
		cout << coordinates[i].row << ", " << coordinates[i].column << endl;
	}
	cout << endl;



	return 0;	
}
