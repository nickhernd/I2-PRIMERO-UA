#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;

// Devuelve el numero de veces que n esta en el vector v.
int veces(vector<int> v, int n){
	int i, veces;
	veces = 0;
	for(i = 0; i < v.size(); i++){
		if(v[i] == n){
			veces++;
		}
	}
	return veces;
}

// rellena con valores aleatorios entre ini y fin ambos incluidos.
// ini = 10
// fin = 99
//		rand() % (99 - 10 + 1) + 10
//		rand() % 90 + 10 = [0.89] + 10 => [10.99]

void fillRandomize(vector<int> &v, int n, int ini, int fin){
	int valor;

	for(int i = 1; i <= n; i++){
		valor = rand() % (fin - ini + 1) + ini;
		v.push_back(valor);
	}
}

void print(vector<int> v){
	cout << "[";
	for(int i = 0; i < v.size(); i++){
		cout << v[i];
		if(i != v.size() - 1){
			cout << ", ";
		}
	}
	cout << "]";
}

// añade al final del vector n veces el valor val
void insertarN(vector<int> &v, int n, int val){
	for(int i = 1; i <= n; i++){ // se repite n veces.
		v.push_back(val);
	}
}

// valores = {2, 3, 1, 5, 3}	n = 5
// queremos meter al final del vector v los valores del vector valroes.
void ini(vector<int> &v, int valores[], int n){
	for(int i = 0; i < n; i++){
		v.push_back(valores[i]);
	}
}

// v1 = {2, 3, 5}
// v2 = {90, 23, 12}
// 	devuelve = {2 3 5 90 23 12}
vector<int> concatenar(vector<int> v1, vector<int> v2){
	vector<int> res;
	// añadimos a res todos los elementos de v1
	res = v1;
	// añadimos a res todos los elementos de v2
	for(int i = 0; i < v2.size(); i++){
		res.push_back(v2[i]);
	}
	return res;
}


int main(){
	vector<int> enteros;
	fillRandomize(enteros, 10, 10, 99);
	print(enteros);
	cout << endl;
	
	vector<int> poyas;
	insertarN(poyas, 5, 0);
	print(poyas);
	cout << endl;

	vector<int> v1;
	vector<int> v2;
	vector<int> resultado;
	
	fillRandomize(v1, 5, 1, 10);
	fillRandomize(v2, 5, 1, 10);
	resultado = concatenar(v1, v2);
	print(v1);
	cout << " + ";
	print(v2);
	cout << " = ";
	print(resultado);
	cout << endl;


	
	return 0;
}
