// IMPORTANTE!!!
// COMO SACAR INFORMACION DE UNA CADENA DE CARACTERES!
#include <iostream>
#include <cstring>
using namespace std;

int main(){
	// el usuario introduce dos numeros separados por una |
	// mostramos por pantalla la suma de ambos numeros
	// ejemplo: 	cadena = "12|341"
	//		mostremos: 12 + 341 = 353
	string cadena, snum1, snum2;
	int i, tam;

	cout << "Introduce una cadena: ";
	getline(cin, cadena);

	// un bucle para extraer caracter los caracteres hasta la |
	snum1 = "";
	i = 0;
	while(cadena[i] != '|'){
		snum1 = snum1 + cadena[i];
		i++;
	}

	// un bucle para extraer el resto caracteres (hasta el final de cadena)
	i++;
	snum2 = "";
	tam = cadena.length();
	while(i < tam){
		snum2 = snum2 + cadena[i];
		i++;
	}
	
	cout << snum1 << " + " << snum2 << " = " << stoi(snum1) + stoi(snum2) << endl; 
	return 0;
}
