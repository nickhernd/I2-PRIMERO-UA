#include <iostream>
#include <cstring>
using namespace std;

int main(){
	// contiene una cadena de caracteres
	// no hay limite de caracteres a almacenar
	// son mutables
	// no contienen el \0 al final de la secuencias
	// se pueden utilizar los operadores < > == != =
	// se puede utilizar el operador [] para acceder a una posicion;
	string texto1, texto2, res;

	texto1 = "jose";
	texto2 = " manuel";
	res = texto1 + texto2 + ".";	// concatenacion
	cout << "cadena: " << res << endl;

	cout << "Introduce una cadena: ";
	getline(cin, texto1);	// hasta el salto de linea
	cout << "Has introducido " << texto1 << endl;
	cout << "Numero de caracteres: " << texto1.length() << endl;

	int tam = texto1.length();
	for(int i = 0; i < tam; i++){
		cout << texto1[i];
		if(i != tam - 1){
			cout << ", ";
		}
	}
	cout << endl;
	
	texto1 = "";	// la cadena esta vacia.
	for(char letra = 'a'; letra <= 'z'; letra++){
		texto1 = texto1 + letra;
	}
	cout << "letritas: " << texto1 << endl;

	return 0;
}
