#include <iostream>
#include <cstring>
using namespace std;

int main(){
	string cadena;
	int pos;

	cout << "Cadena: ";
	getline(cin, cadena);

	pos = cadena.find(",");

	if(pos == string::npos){
		cout << "No he encontrado la subcadena" << endl;
	}
	else{
		cout << "Lo he encontrado en " << pos << endl;
	}
	
	// extraeme desde la posicion 0, caracteres
	cout << cadena.substr(0, pos) << endl;
	
	// si no le ponemos un segundo entero me extrae hasta el final
	cout << cadena.substr(pos + 1) << endl;

	return 0;
}
