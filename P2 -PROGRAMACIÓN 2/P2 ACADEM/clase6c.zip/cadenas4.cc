#include <iostream>
using namespace std;



// SUPER MEGA IMPORTANTE ESTE EJEMPLO!!!

//  guarda los numeros de la cadena en el vector de enteros y luego los imprime.

int main(){
	string cadena, aux;
	vector<int> enteros;
	int i, tam;


	cout << "Introduce los numeros a sumar separados por comas?: ";
	getline(cin, cadena);
	// cadena = "12,23,34,123"

	tam = cadena.length();
	// haced un bucle que pille solo hasta la primera , y guardar el entero
	// en el vector
	
	i = 0;
	while(i < tam){	
		aux = "";		
		while(i < tam && cadena[i] != ','){
			aux = aux + cadena[i];
			i++;
		}
		enteros.push_back(stoi(aux));
		i++;
	}
	for(int i = 0; i < enteros.size(); i++){
		cout << enteros[i] << " ";
	}
	cout << endl;

	return 0;
}
