#include <iostream>
#include <cstring>
using namespace std;



// pedir una cadena que contendra una serie de digitos
// a continuacion una barra y a continuacion otra serie de digitos
// Mostrad por pantalla la suma de los numeros.
int main(){
	int i, tam;
	string cad;
	string aux1, aux2;

	// El formato de la cadena es correcto.
	// "2233|4345"
	// "-34|3565"
	// "34|-245"
	cout << "Dame una cadena d*|d*?: ";
	getline(cin, cad);

	aux1 = "";
	i = 0;
	while(cad[i] != '|'){
		aux1 = aux1 + cad[i];
		i++;
	}
	
	tam = cad.length();
	aux2 = "";
	i = i + 1;  // me salto la barra.	
	while(i < tam){
		aux2 = aux2 + cad[i];
		i++;
	}	
	
	cout << aux1 + aux2 << endl;
	cout << stoi(aux1) + stoi(aux2) << endl;

	return 0;
}
