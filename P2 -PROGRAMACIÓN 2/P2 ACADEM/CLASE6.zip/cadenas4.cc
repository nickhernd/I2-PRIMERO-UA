#include <iostream>
#include <cstring>
#include <vector>
using namespace std;


// Ahora no sabemos cuantos numeros vamos a tener separados por |

// Realiza un progama que meta todos los numeros que hay en la cadena
// en un vector de enteros.

//           iiii    iii     iiii
// cadena = "343|345|23|2545|234"
//               iiii   iiiii

int main(){
	int i, tam;
	string cad, aux;
	vector<int> enteros;


	cout << "Introduce una cadena con los numeros separados por | : ";
	getline(cin, cad);

	i = 0;
	tam = cad.length();
	while(i < tam){
		aux = "";
		while(i < tam && linea[i] != '|'){
			aux = aux + linea[i];
			i++;
		}
		enteros.push_back(stoi(aux));
		i = i + 1; // para saltarse la |
	}

	return 0;
}
