#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

/*
	isalpha()
	isalnum()
	isdigit()
	tolower()
	toupper()
	islower()
	isupper()
*/

bool esVocal(char vocal){
	vocal = tolower(vocal);
	return vocal == 'a' || vocal == 'e' || vocal == 'i' || vocal == 'o'
	|| vocal == 'u';
}

int main(){
	int tam;
	string cadena;
	string vocales, consonantes;

	cout << "Introduce una cadena: ";
	getline(cin, cadena);

	tam = cadena.length();
	vocales = "";
	consonantes = "";
	for(int i = 0; i < tam; i++){
		if(isalpha(cadena[i]) != 0){
			if(esVocal(cadena[i]) == true){
				vocales += cadena[i];
			}
			else{
				consonantes += cadena[i];
			}
		}
	}
	cout << "Consontantes: " << consonantes << endl;
	cout << "Vocales: " << vocales << endl;

	return 0;
}
