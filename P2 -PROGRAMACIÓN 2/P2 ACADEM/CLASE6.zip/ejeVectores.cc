#include <iostream>
#include <vector>
using namespace std;

int veces(vector<int> v, int n){
	int i, veces;
	veces = 0;
	for(i = 0;i < v.size(); i++){
		if(v[i] == n){
			veces++;
		}
	}
	return veces;
}

// v1 = {1, 2, 4}
// v2 = {5, 6}
// deveuvel {1, 2, 4, 5, 6}
vector<int> concat(const vector<int> &v1, const vector<int> &v2){
	vector<int> resultado;

	resultado = v1;
	// recorremos los elementos de v2 y los añadimos al final de v1.
	for(int i = 0; i < v2.size(); i++){
		resultado.push_back(v2[i]);
	}
	return resultado;
}

vector<int> concatEach(const vector<int> &v1, const vector<int> &v2){
	vector<int> resultado;
	
	resultado = v1;
	for(int e : v2){
		resultado.push_back(e);
	}
	return resultado;
}

// v = {3} n = 5, valor = 7
// v = {3, 7, 7, 7, 7, 7}
void insertarN(vector<int> &v, int n, int valor){
	for(int i = 1; i <= n; i++){
		v.push_back(valor);
	}
}

void ini(vector<int> &v, int valores[], int n){
	for(int i = 0; i < n; i++){
		v.push_back(valores[i]);
	}
}

// mete n valores aleatorios entre [ini, fin] al final del vector.
// ini = 10
// fin = 15
//		fin - ini + 1 = 6
//		el resto esta entre 0 y 5 + 10 => 10 y 15
void randomize(vector<int> &v, int n, int ini, int fin){
	int valor;
	for(int i = 1; i <= n; i++){
		valor = rand() % (fin - ini + 1) + ini;
		v.push_back(valor);
	}
}

// suponiendo que el vector v ya esta ordenado de menor a mayor.
// meted el nuevo elemento en el vector de forma que se quede ordenado.
//      0  1  2   3   4
// v = {1, 3, 8, 10, 12}
// nuevo = 4
void insertarOrdenado(vector<int> &v, int nuevo){
	int i, aux;

	// bublesort		
			    //                  i
	v.push_back(nuevo); // 1, 3, 8, 10, 12, 4
	i = v.size() - 1;	
	while(i > 0 && v[i] < v[i-1]){
		aux = v[i];
		v[i] = v[i-1];
		v[i-1] = aux;
		i--;
	}
	
}

// mete n valores aleatorios entre [ini, fin] al final del vector.
// ini = 10
// fin = 15
//		fin - ini + 1 = 6
//		el resto esta entre 0 y 5 + 10 => 10 y 15
void randomizeOrdered(vector<int> &v, int n, int ini, int fin){
	int valor;
	for(int i = 1; i <= n; i++){
		valor = rand() % (fin - ini + 1) + ini;
		insertarOrdenado(v, valor);
	}
}


//      i  i  i
//      0  1  2   3   4
// v = {1, 3, 8, 10, 12}
// nuevo = 4
void insertarOrdenado2(vector<int> &v, int nuevo){
	int i;

	i = 0;
	while(i < v.size() && nuevo > v[i]){
		i++;
	}
	// inserta en la posicion i el valor nuevo, desplazando
	// todos los elementos una posicion a la derecha.
	v.insert(v.begin() + i, nuevo);
}

void print(const vector<int> &v){
	cout << "[";
	for(int i = 0; i < v.size(); i++){
		cout << v[i];
		if(i != v.size() - 1){
			cout << ", ";
		}
	}
	cout << "]";
}

// PROPUESTO 0
// Funcion que recibe un valor y un vector y devuelve la primera posicion
// donde aparece el valor en el vector.

// PROPUESTO 1
// Modifica randomizeOrdered, para que no genere elementos repetidos.


int main(){
	vector<int> javi;

	randomize(javi, 20, 10, 99);
	print(javi);
	cout << endl;

	javi.clear();
	randomizeOrdered(javi, 10, 10, 99);
	print(javi);
	cout << endl;

	return 0;
}


