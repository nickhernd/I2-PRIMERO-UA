#include <iostream>
#include <cstring>
using namespace std;


int main(){
	// El tipo cadena.
	string cadena;	// No existe el \0 y no tenemos maximo.
	int tam, j;

	cadena = "jose";
	cout << "Longitud: " << cadena.length() << endl;
	cout << "En la cadena: " << cadena << endl;
	
	cadena = cadena + " manuel";
	cout << cadena << endl;
	
	cout << "[";
	tam = cadena.length();
	for(int i = 0; i < tam; i++){
		cout << cadena[i];
		if(i != tam - 1){
			cout << ", ";
		}
	}
	cout << "]" << endl;

	cout << "Introduce una cadena: ";
	getline(cin, cadena);
	cout << "La cadena es: " << cadena << endl;

	cadena = "";
	cout << "Ahora la cadena esta vacia " << cadena.length() << endl;

	cadena = "345";
	cout << stoi(cadena) + 10 << endl;


	// Es un vector de caracteres
	char vector[100]; // el maximo numero es 99 + \0
	strcpy(vector, "jose");		// strcpy(char dest[], char org[])
	
	cout << "Longitud: " << strlen(vector) << endl; // 4	
	cout << "En el vector: " << vector << endl;

	strcat(vector, " manuel");
	cout << vector << endl;

	// imprimo caracter a caracter el contenido del vector
	// [j, o, s, e,  , m, a, n, u, e, l]
	int i = 0;
	cout << "[";
	while(vector[i] != '\0'){
		cout << vector[i];
		if(vector[i+1] != '\0'){
			cout << ", ";
		}
		i++;
	}
	cout << "]" << endl;
	
	cout << "Introduce una cadena de caracteres: ";
	cin.getline(vector, 100);
	cout << "Contenido de la cadena es: " << vector << endl;

	vector[0] = '\0';
	strcpy(vector, "");
	cout << "Ahora el vector esta vacio: " << strlen(vector) << endl;

	strcpy(vector, "345");
	cout << atoi(vector) + 10 << endl;


	return 0;
}
