#include <iostream>
#include <vector>
#include <cstring>
#include <sstream>
using namespace std;

struct Esta{
	string name, email, mainIp;
	vector<string> ips;
};


int main(){
	int i;
	Esta esta;
	string cad = "kiki karlos:jkarloshot@onlyfans.com:123.0.0.1:1|23|234";
	string ip;	
	stringstream buf(cad);

	// el caracter que rompe la cadena se lee pero no se almacena en la caden.
	getline(buf, esta.name, ':');
	getline(buf, esta.email, ':');
	geltine(buf, esta.mainIp, ':');

	do{
		getline(buf, ip, ':');
		esta.ips.push_back(ip);
	}while(buf.eof() == false);
	
	return 0;
}
