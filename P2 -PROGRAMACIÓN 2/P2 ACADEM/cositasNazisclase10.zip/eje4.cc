#include <iostream>
#include <cstring>
#include <sstream>
#include<vector>
using namespace std;

int main(){
	string ext;
	string cad = "informasion:mas informasion:un poco mas:ge ge";
	vector<string> extraidas;
	stringstream ss(cad);

	do{
		getline(ss, ext, ':');		
		extraidas.push_back(ext);
	}while(ss.eof() == false);
	

	for(string cadenitas : extraidas){
		cout << cadenitas << endl;
	}

}
