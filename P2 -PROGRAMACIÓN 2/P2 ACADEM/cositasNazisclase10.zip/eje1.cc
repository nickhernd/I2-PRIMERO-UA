#include <iostream>
#include <sstream>
using namespace std;

int main(){

	//            01234
	//            g   g
	string cad = "  12   324  23";
	//                456789
	//                      g
	int num1, num2, num3;
	
	stringstream buf(cad);	// buffer a partir de una cadena.


	// >> ignora todos los espacios y los \n que se encuentre 
	// lee hasta llegar a espacio o \n.
	cout << buf.eof() << endl;
	cout << buf.tellg() << endl;	
	buf >> num1;
	cout << buf.tellg() << endl;	
	buf >> num2; 
	cout << buf.tellg() << endl;
	buf >> num3;
	cout << buf.tellg() << endl;
	cout << buf.eof() << endl;

	cout << "leido: " << num1 << ", " << num2 << ", " << num3 << endl;
	cout << buf.str() << endl;
	
	return 0;
}
