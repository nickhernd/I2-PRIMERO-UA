#include <iostream>
#include <vector>
#include <sstream>
using namespace std;


// devuelve un vector de enteros con los enteros contenidos en la cadena.
// los enteros pueden estar separados por unos o varios espacios y podemos
// tener espacios al princpio y al final de la cadena.
// NO PODEIS UTILIZAR stringstream.

//   iiii  xxxxx xxxx   xxxx
//   012345          
//  "   234    34   123 423     "
//      iiii   xxx  xxxx   iiiiii
vector<int> obtenerCadenas(string cad){
	string s;
	int i, tam;
	vector<int> resultado;
	tam = cad.length();
	i = 0;
	while(i < tam){
		// me salto los espacios
		while(i < tam && cad[i] == ' '){
			i++;
		}
		s = "";
		// coger la cadena
		while(i < tam && cad[i] != ' '){
			s += cad[i];
			i++;
		}
		// almaceno la puta cadena.
		if(!s.empty()){
			resultado.push_back(stoi(s));
		}
	}
	return resultado;
}
vector<int> obtenerCadenasWB(string cad){
	stringstream ss(cad);
	vector<int> resultado;
	int num;
	ss >> num;
	while(!ss.eof()){
		resultado.push_back(num);
		ss >> num;
	}
	return resultado;
}
int main(){
	vector<int> r;
	r = obtenerCadenasWB("   23   23   123   43   ");
	for(int valor : r){
		cout << valor << " ";
	}
	cout << endl;
}


