#include <iostream>
#include <cstring>
using namespace std;

struct Coordinate{
    int row;
    int column;
};


int main(){
	Coordinate obstacles[20];
	char linea[100];
	int i, k;
	
	cout << "Linea: ";
	cin.getline(linea, 100);

	cout << "Has introducido la liena: " << linea << endl;


	// imprime cada caracter de la cadena en una linea!!
	i = 0;
	while(linea[i] != '\0'){
		cout << linea[i] << endl;
		i++;
	}
	cout << endl;

	//         i       i       i          i
	//	   0 1 2 3 4 5 6 7 8 9 10 11 
	// linea = 3 , 2 | 1 , 0 | 3 , 9  \0
// 123,123|

	// i = 0, k = 0
	obstacles[0].row = linea[0] - '0';
	obstacles[0].column = linea[2] - '0';

	// i = 4, k = 1
	obstacles[1].row = linea[4] - '0';
	obstacles[1].column = linea[6] - '0';

	// TODO 
	i = 0;
	k = 0;
	while(i < strlen(linea)){
		cout << linea[i] << " " << linea[i+2] << endl;;
		i = i + 4;
	}
	cout << endl;

	return 0;
}
