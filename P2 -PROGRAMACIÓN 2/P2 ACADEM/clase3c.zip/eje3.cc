#include <iostream>
using namespace std;

struct Coordinate{
    int row;
    int column;
};

int main(){
	Coordinate obstacles[20] = {{2, 0}, {3, 1}, {3, 5}, {4, 5}, {5, 0}, {5, 3}, {5, 6}};
	int numObstacles = 7;

	// realiza un programa que pida una coordenada i, j y muestre por pantalla si dicha
	// coordenada esta o NO esta en el vector.
	int i, j;
	bool encontrado;

	cout << "i: ";
	cin >> i;
	cout << "j: ";
	cin >> j;
	encontrado = false;
	for(int k = 0; k < numObstacles && encontrado == false; k++){
		if(i == obstacles[k].row && j == obstacles[k].column){
			encontrado = true;
		}
	}
	if(encontrado == true){
		cout << "Lo he encontrado" << endl;
	}
	else{
		cout << "No lo he encontrado" << endl;
	}

	return 0;
}
