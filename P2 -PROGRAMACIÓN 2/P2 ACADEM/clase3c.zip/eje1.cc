#include <iostream>
using namespace std;


int main(){
	int size;

	cout << "size: ";
	cin >> size;

	for(int j = 0; j < size; j++){
		cout << "O ";
	}
	cout << endl;
	cout << endl;
	cout << endl;

	for(int i = 0; i < size; i++){
		cout << i << ": ";
		for(int j = 0; j < size; j++){
			cout << "O ";
		}
		cout << endl;
	}
	cout << endl;
	cout << endl;
	cout << endl;

	for(int i = 0; i < size; i++){
		for(int j = 0; j < size; j++){
			cout << "(" << i << ", " << j << ") ";
		}
		cout << endl;
	}
	cout << endl << endl << endl;
	int x1, y1, x2, y2;
	
	cout << "x1: ";
	cin >> x1;
	cout << "y1: ";
	cin >> y1;
	cout << "x2: ";
	cin >> x2;
	cout << "y2: ";
	cin >> y2;
	for(int i = 0; i < size; i++){
		for(int j = 0; j < size; j++){
			if(i == x1 && j == y1 || i == x2 && j == y2){
				cout << "X ";
			}
			else{
				cout << "O ";
			}
		}
		cout << endl;
	}
	


}
