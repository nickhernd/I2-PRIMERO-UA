#include <iostream>
#include <vector>
using namespace std;

const int KMAXOBSTACLES = 20;

struct Coordinate{
    int row;
    int column;
};

struct Level{
    int id;
    int size;
    int numObstacles;
    Coordinate obstacles[KMAXOBSTACLES]; // vector<Coodinate> obstacles;
    Coordinate start;
    Coordinate finish;
};

int main(){
	Level level = {
		1,	// level.id
		7,	// level.size
		4,	// level.numObstacles
		{{0, 3}, {2, 5}, {3, 2}, {6, 5}},	// level.obstacles[0].row, level.obstacles[0].column, level.obstacles[1].row, level.obstacles[1].column
		{6, 0}, // level.start.row level.start.column
		{0, 6}  // level.finish.row level.finish.column
	};
	bool encontrado;

	// Cuando pasa por Start imprime una S y cuando pase por la coordenada Finish imprime una F
	for(int i = 0; i < level.size; i++){
		for(int j = 0; j < level.size; j++){
			if(level.start.row == i && level.start.column == j){
				cout << "S ";
			}
			else{
				if(level.finish.row == i && level.finish.column == j){
					cout << "F ";
				}
				else{
					// si la coordenada i, j esta en el vector de obstacles, tengo que imprimir una X
					encontrado = false;
					for(int k = 0; k < level.numObstacles && encontrado == false; k++){
						if(i == level.obstacles[k].row && j == level.obstacles[k].column){
							encontrado = true;
						}
					}
					if(encontrado == true){
						cout << "X ";				
					}
					else{
						cout << "O ";
					}
				}
			}
		}
		cout << endl;
	}

	vector<Level> levels;
	levels.push_back(level);
	levels.push_back(level);
	levels.push_back(level);

	return 0;
}
