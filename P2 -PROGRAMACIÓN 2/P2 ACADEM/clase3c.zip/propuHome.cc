#include <iostream>
using namespace std;

const int KMAXOBSTACLES = 20;

struct Coordinate{
    int row;
    int column;
};
struct Level{
    int id;
    int size;
    int numObstacles;
    Coordinate obstacles[KMAXOBSTACLES];
    Coordinate start;
    Coordinate finish;
};

void printLevel(Level level);

// TODO haced el eje2.cc con FUNCIONES

int main(){
	Level level = {
		1,	// level.id
		7,	// level.size
		3,	// level.numObstacles
		{{0, 3}, {2, 5}, {3, 6}},	// level.obstacles[0].row, level.obstacles[0].column, level.obstacles[1].row, level.obstacles[2].column
		{6, 0},	// level.start.row, level.start.column
		{0, 6} // level.finish.row, level.finish.column
	};
	printLevel(level); 

	return 0;
}

void printLevel(Level level){
	

}
