#include <iostream>
#include <vector>
using namespace std;

const char KMSG1[] = "Name: ";
const int KNAME=40;
const int KMAXOBSTACLES=20;
const int KSIZES[] = {5, 7, 10};

const int KMAXLEVELS = 10; // la he añadido yo.

enum Error{
    ERR_OPTION,
    ERR_DIFFICULTY,
    ERR_LEVEL,
    ERR_COORDINATE,
    ERR_OBSTACLES,
    ERR_ID,
    ERR_INSTRUCTION
};

// Registro para las coordenadas
struct Coordinate{
    int row;
    int column;
};

// Registro para el jugador
struct Player{
    char name[KNAME];
    int difficulty;
    int score;
    int wins;
    int losses;
};

// Registro para el nivel
struct Level{
    int id;
    int size;
    int numObstacles;
    Coordinate obstacles[KMAXOBSTACLES]; // vector<Coodinate> obstacles;
    Coordinate start;
    Coordinate finish;
};

// Función que muestra los mensajes de error
void error(Error e){
    switch(e){
        case ERR_OPTION: cout << "ERROR: wrong option" << endl;
            break;
        case ERR_DIFFICULTY: cout << "ERROR: wrong difficulty" << endl;
            break;
        case ERR_LEVEL: cout << "ERROR: cannot create level" << endl;
            break;
        case ERR_COORDINATE: cout << "ERROR: wrong coordinate" << endl;
            break;
        case ERR_OBSTACLES: cout << "ERROR: wrong number of obstacles" << endl;
            break;
        case ERR_ID: cout << "ERROR: wrong id" << endl;
            break;
        case ERR_INSTRUCTION: cout << "ERROR: wrong instruction" << endl;
            break;
    }
}

// Función que muestra el menú de opciones
void showMenu(){
    cout << "[Options]" << endl
        << "1- Create level" << endl
        << "2- Delete level" << endl
        << "3- Show levels" << endl
        << "4- Play" << endl
        << "5- Report" << endl
        << "q- Quit" << endl
        << "Option: ";
}
/*
	0	1	2	3	4
	------------------
	ID	ID	ID	ID	ID
	1	2	3	4	5

	BORRO ANTES DE AÑADIR 2 3 4

	0	1
	-----------	EL SIGUIENTE ID NO ES EL TAMAÑO DEL VECTOR + 1.
	ID	ID
	1	5

*/
void createLevel(vector<Level> &levels, int &numLevels, int difficulty){
	// sacar un mensaje de error si levels.size() ...
	Level nuevo;
	
	if(levels.size() == KMAXLEVELS){
		error(ERR_LEVEL);
	}
	else{
		nuevo.id = numLevels + 1;
		numLevels++;
		switch(difficulty){
			case 1:				
				nuevo.size = 5;
				break;
			case 2:
				nuevo.size  = 7;
				break;
			case 3:
				nuevo.size = 10;
				break;
		} 
		// nuevo.size = KSIZES[difficulty - 1];

/*		nuevo.start.row = nuevo.size - 1;
		nuevo.start.column = 0;
		nuevo.finish.row = 0;
		nuevo.finish.column = nuevo.size - 1; */

		nuevo.start = {nuevo.size - 1, 0};
		nuevo.finish = {0, nuevo.size - 1};

		// LO DEJO ASI DE MOMENTO.
		nuevo.numObstacles = 0;


		// añade una posicion al final del vector y copia en esa posicion
		// los valores de la variable que le pasemos como argumento.
		levels.push_back(nuevo);
	}
}

void readPlayer(Player &player){
	cout << KMSG1;
	cin.getline(player.name, KNAME);
	do{	
		cout << "Difficulty: ";
		cin >> player.difficulty;
		cin.get();
		if(player.difficulty < 1 || player.difficulty > 3){
			error(ERR_DIFFICULTY);
		}
	}while(player.difficulty < 1 || player.difficulty > 3);
	player.score = 0;
	player.wins = 0;
	player.losses = 0;
}


Player readPlayer2(){
	Player player;
	cout << KMSG1;
	cin.getline(player.name, KNAME);
	do{	
		cout << "Difficulty: ";
		cin >> player.difficulty;
		cin.get();
		if(player.difficulty < 1 || player.difficulty > 3){
			error(ERR_DIFFICULTY);
		}
	}while(player.difficulty < 1 || player.difficulty > 3);
	player.score = 0;
	player.wins = 0;
	player.losses = 0;
	return player;
}

void deleteLevel(vector<Level> &levels){
	int id;
	char res;
	int pos;

	cout << "Id: ";
	cin >> id;
	cin.get();

	// buscamos la posicion del nivel cuyo id es el id que acaba
	// de introducir el usuario.
	pos = -1;
	for(int i = 0; i < levels.size() && pos == -1; i++){
		if(id == levels[i].id){
			pos = i;
			// levels.erase(levels.begin() + pos);
		}
	}
	if(pos == -1){
		error(ERR_ID);
	}
	else{
		// preguntamos al usuario si lo quiere eliminar.
		do{	
			cout << "Are you sure? [y/n] ";
			cin >> res;
		}while(res != 'y' && res != 'Y' && res != 'n' && res != 'N');
		if(res == 'y' || res == 'Y'){
			levels.erase(levels.begin() + pos);
		}
	}
	
}

void report(Player player){
	int total;

	total = player.wins + player.losses;
	cout << "[Report]" << endl;
	cout << "Name: " << player.name << endl;
	
	cout << "Difficulty: ";;
	switch(player.difficulty){
		case 1:
			cout <<"Easy" << endl;
			break;
		case 2:
			cout <<"Medium" << endl;	
			break;
		case 3:
			cout << "Hard" << endl;
			break;
	}
	cout << "Score: " << player.score << endl;
	cout << "Wins: " << player.wins << endl;
	cout << "Losses: " << player.losses << endl;
	cout << "Total: " << total << endl;
}

// Función principal (tendrás que añadirle más código tuyo)
int main(){
    char option;
    Player player;
	vector<Level> levels;
	int numLevels = 0;


	readPlayer(player);
	// player = readPlayer2();
    do{
        showMenu();
        cin >> option;
        cin.get(); // Para evitar que el salto de línea se quede en el buffer de teclado y luego pueda dar problemas si usas "getline"
        
        switch(option){
        	case '1': // Llamar a la función para crear un nuevo nivel
				createLevel(levels, numLevels, player.difficulty);
                break;
            case '2': // Llamar a la función para borrar un nivel existente
				deleteLevel(levels);
                break;
            case '3': // Llamar a la función para mostrar los niveles creados
                break;
            case '4': // Llamar a la función para jugar
                break;
            case '5': // Llamar a la función para mostrar información del jugador
		report(player);
                break;
            case 'q': break;
            default: error(ERR_OPTION); // Muestra "ERROR: wrong option"
        }
    }while(option!='q');
}
