#include <iostream>
using namespace std;


// devuelve un vector con los 4 trozos de la cadena
// delmitados por .
// trozo1.trozo2.trozo3.trozo4
// 	vector = <"trozo1", "trozo2", "trozo3, "trozo4">
vector<string> sacarNumeros(string n){

}

// comprueba, comprueba que n es un numero entre 0 y 255
// y no puede empezar por 0 a no ser que sea 0
bool testNumber(string n){

}

int main(){

	return 0;
}
