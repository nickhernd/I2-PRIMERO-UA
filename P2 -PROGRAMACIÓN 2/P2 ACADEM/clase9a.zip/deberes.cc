#include <string>
#include <iostream>
#include <cctype>
using namespace std;
/*
	 Devuelve si el caracter esta o no en la cadena.
*/
bool search(string cad, char c){
	bool found = false;
	for(int i = 0; i < cad.length() && !found; i++){
		if(cad[i] == c){
			found = true;
		}
	}
	return found;
}
/*
	 Devuelve la posicion donde esta el caracter en la cadena.
	 -1 si no esta en la cadena.
*/
int searchPos(string cad, char c){
	int i, pos;
	pos = -1;
	for(i = 0; i < cad.length() && pos == -1; i++){
		if(cad[i] == c){
			pos = i;
		}
	}
	return pos;
}
/*
	Devuelve cierto si la longitud esta entre 4 y 10
	y todos los caracteres son letras minusculas.
*/
bool cmpName(string n){
	bool correcto = false;
	if(n.length() >= 4 && n.length() <= 10){
		correcto = true;
		for(int i = 0; i < n.length() && correcto; i++){
			if(islower(n[i]) == 0){
				correcto = false;
			}
		}
	}
	return correcto;
}

/*
	Devuelve cierto si la cadena tiene dos partes
	una en la que todo son digitos y luego otra en
	la que todo son letras, cualquier parte puede estar
	vacia:
		123321asdfasfda
		afddsfasdf
		234324
		=> 132addfa12313
*/
bool twoFaces(string n){
	int i, tam;
	bool res = true;
	
	tam = n.length();
	i = 0;
	while(i < tam && isdigit(n[i]) != 0){
		i++;
	}
	
	res = true;
	while(i < tam && res == true){
		if(isalpha(n[i]) == 0){
			res = false;
		}
		else{
			i++;
		}
	}
	return res;
}

/*
	Devuelve cierto si solo contiene digitos,
	es decir caracteres nuemricos

	31413241
	3214a2342 NO
*/
bool onlyDigits(string n){
	bool only = true;
	for(int i = 0; i < n.length() && !only; i++){
		if(isdigit(n[i]) == 0){
			only = false;
		}
	}
	return only;
}

// devuelve cierto si todos los caracteres de la cadena n
// aparecen en el conjunto de caracteres charset
//	validCharset("134aa", "1234556789abc") => true
//	validCharset("134aaz", "1234556789abc") => false
bool validCharset(string n, string charset){
	bool es = true;
	for(int i = 0; i < n.length() && es == true; i++){
		if(charset.find(n[i]) == string::npos){
			es = false;
		}
	}
	return es;
}

int main(){

	return 0;
}




