#include <iostream>
using namespace std;

// minimo 3 caracteres y que no tenga : sol
bool validateName(string name){
	int tam, i;
	bool correct = false;

	tam = name.length();
	if(tam >= 3){
		if(name.find(':') != string::npos){
			correct = false; 
		}
		else{
			correct = true;
		}
	}
	return correct;
	// return name.length() >= 3 && name.find(':') != string::npos;
}

// letras o digitos o el caracter subrayado y no puede empezar por digito
// y no puede estar vacio
bool validateVariableName(String name){
	bool valid = false;
	int tam = name.length();

	if(tam != 0){
		if(isdigit(name[0]) == 0){
			valid = true;
			for(int i = 0; i < name.length() && valid; i++){
				if(name[i] != '_' && isalnum(name[i]) == 0){
					valid = false;
				}
			}
		}
	}
	return valid;
}

// solo una @ que delimita dos partes
// 	primera parte: letras numeros . _ (no puede empezar por . ni terminar .)
//	segunda parte: lo mismo pero tiene que tener minimo un .
//	ninguna parte podra estar vacia (by elena)
bool validateEmail(string email){
	int cuantas, i;
	bool valid;
	bool dotfound;
	
	cuantas = 0;
	for(i = 0; i < email.length(); i++){
		if(email[i] == '@'){
			cuantas++;
		}
	}
	if(cuantas != 1){
		valid = false;
	}
	else{
		if(email[0] != '.' && email[0] != '@'){
			valid = false;
		}
		else{
			valid = true;
			for(i = 0; email[i] != '@' && valid; i++){
				if(email[i] != '.' && email[i] != '_' && isalnum(email[i]) == 0){
					valid = false;
				}
			}
			if(email[i-1] == '.'){
				valid = false;
			}
			else{
				i++;
				if(email[i] == '.' || i == email.length()){
					valid = false;
				}
				else{
					dotfound = false;
					valid = true;
					while(i < email.length() && valid){
						if(email[i] == '.'){
							dotfound = true;
						}
						if(email[i] != '.' && email[i] != '_' && isalnum(email[i]) == 0){
							valid = false;
						}
						else{
							i++;
						}
					}
					if(dotfound == false || email[i-1] == '.'){
						valid = false;
					}
				}
			}
		}
	}
	return valid;
}


bool validate(string left){
	int tam = left.length();
	bool valid = false;

	if(tam > 0){
		if(left[0] != '.' && left[tam - 1] != '.'){
			// letra digito _ o .
			valid = true;
			for(int i = 0; i < tam && valid; i++){
				if(left[i] != '_' && left[i] != '.' && isalnum(left[i]) == 0){
					valid = false;
				}
			}
		}
	}
	return valid;
}

bool validateEmailCool(string email){
	bool valid = false;
	int pos;
	string izquierda, derecha;
	pos = email.find('@');
	if(pos != string::npos){
		izquierda = email.substr(0, pos); // desde 0 pos caracteres
		derecha = email.substr(pos + 1); // desde pos + 1 hasta el final
		if(validate(izquierda) && validate(derecha) && derecha.find('@') == string::npos && derecha.find('.') != string::npos){
			valid = true;
		}		
	}
	return valid;
}





// 4 numeros separados por el caracter .
// de 0 a 255 both includes
bool validateIp(string ip){
	

}


int main(){
	

	return 0;
}
