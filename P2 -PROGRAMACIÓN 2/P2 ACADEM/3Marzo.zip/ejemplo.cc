#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int main(){
	vector<string> palabras = {"la", "le", "li", "lo", "lu"};
	ofstream fich;

	fich.open("cadenas.txt");
	if(fich.is_open()){
		for(string s : palabras){
			fich << s << endl;
		}
		fich.close();
	}
	

	return 0;
}
