#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

const int KMAXSTRING = 50;
const int KMAXIP = 16;

enum Error {
  ERR_OPTION,
  ERR_NAME,
  ERR_EMAIL,
  ERR_ID,
  ERR_IP,
  ERR_FILE,
  ERR_ARGS
};

struct Subscriber {
  unsigned int id;
  string name;
  string email;
  string mainIp;
  vector<string> ips;
};

struct BinSubscriber {
  unsigned int id;
  char name[KMAXSTRING];
  char email[KMAXSTRING];
  char mainIp[KMAXIP];
};

struct Platform {
  string name;
  vector<Subscriber> subscribers;
  unsigned int nextId;
};

struct BinPlatform {
  char name[KMAXSTRING];
  unsigned int nextId;
};

void error(Error e) {
  switch (e) {
    case ERR_OPTION:
      cout << "ERROR: wrong menu option" << endl;
      break;
    case ERR_NAME:
      cout << "ERROR: wrong name" << endl;
      break;
    case ERR_EMAIL:
      cout << "ERROR: wrong email" << endl;
      break;
    case ERR_ID:
      cout << "ERROR: wrong subscriber id" << endl;
      break;
    case ERR_IP:
      cout << "ERROR: wrong IP" << endl;
      break;
    case ERR_FILE:
      cout << "ERROR: cannot open file" << endl;
      break;
    case ERR_ARGS:
      cout << "ERROR: wrong arguments" << endl;
      break;
  }
}

void showMainMenu() {
  cout << "[Options]" << endl
       << "1- Show subscribers" << endl
       << "2- Add subscriber" << endl
       << "3- Add subscriber IP" << endl
       << "4- Delete subscriber" << endl
       << "5- Import/export" << endl
       << "q- Quit" << endl
       << "Option: ";
}

void showSubscribers(const Platform &platform) {
	for(int i = 0; i < platform.subscribers.size(); i++){
		cout << platform.subscribers[i].id << ":";
		cout << platform.subscribers[i].name << ":"
			<< platform.subscribers[i].email << ":"
			<< platform.subscribers[i].mainIp << ":";
		for(int j = 0; j < platform.subscribers[i].ips.size(); j++){
			cout << platform.subscribers[i].ips[j];
			if(j != platform.subscribers[i].ips.size()){
				cout << "|";
			}
		}
		cout << endl;
	}
}

void showSubscribers2(const Platform &platform) {
	for(Subscriber sub : platform.subscribers){
		cout << sub.id << ":" << sub.name << ":" << sub.email << ":"
		<< sub.mainIp << ":";
		for(int i = 0; i < sub.ips.size(); i++){
			cout << sub.ips[i];
			if(i != sub.ips.size() - 1){
				cout << "|";
			}
		}
		cout << endl;
	}
}

// devuelve si el caracter esta o no en la cadena.
bool search(string cad, char c){
	bool encontrado = false;
	return encontrado;
}

// devuelve la posicion donde esta el caracter en la cadena.
// -1 si no esta en la cadena.
int searchPos(string cad, char c){
	int pos = -1;
	return pos;
}

bool validateName(string name){
	return name.length() >= 3 && name.find(':') == string::npos;
}

bool validateEmail(string email){
	bool ok;
	return ok;
}

void addSubscriber2(Platform &platform) {
	Subscriber sub;
	bool okName, okEmail;

	cout << "Enter name: ";
	getline(cin, sub.name);
	okName = validateName(sub.name);
	if(okName){
		cout << "Enter email: ";
		getline(cin, sub.email);
		okEmail = validateEmail(sub.email);
		if(okEmail){
			sub.id = platform.nextId;
			sub.mainIp = "";
			platform.nextId++;
			platform.subscribers.push_back(sub);
		}
		else{
			error(ERR_EMAIL);
		}
	}
	else{
		error(ERR_NAME);
	}
}

// version que valida el nombre, sin funcion auxiliar.
void addSubscriber(Platform &platform) {
	Subscriber sub;

	cout << "Enter name: ";
	getline(cin, sub.name);
	if(sub.name.length() >= 3){
		if(sub.name.find(':') == string::npos){
			cout << "Enter email: ";
			getline(cin, sub.email);
			sub.id = platform.nextId;
			sub.mainIp = "";
			platform.nextId++;
			platform.subscribers.push_back(sub);
		}
		else{
			error(ERR_NAME);
		}
	}
	else{
		error(ERR_NAME);
	}
}

int searchId(vector<Subscriber> subscribers, int id){
	int pos, i;
	i = 0;
	while(i < subscribers.size() && subscribers[i].id != id){
		i++;
	}
	if(i == subscribers.size()){
		pos = -1;
	}
	else{
		pos = i;
	}
	return pos;
}
bool validate_ip(string ip){
	bool ok = false;
	if(ip.length() != 0){
		ok = true;
	}
	return ok;
}

void addSubscriberIp(Platform &platform) {
	int id, pos, vecesMain, vecesNueva;
	string s_id, ip;
	bool ok_ip;
	

	cout << "Enter subscriber id: ";
	getline(cin, s_id);
	if(s_id.empty() == true){  // if(s_id != ""){
		error(ERR_ID);
	}
	else{
		id = stoi(s_id);
		pos = searchId(platform.subscribers, id);
		if(pos == -1){
			error(ERR_ID);
		} 
		else{
			cout << "Enter IP: ";
			getline(cin, ip);
			ok_ip = validate_ip(ip);
			if(ok_ip == false){
				error(ERR_IP);	
			}
			else{
				platform.subscribers[pos].ips.push_back(ip);
				// comprobamos si tenemos que actualizar la mainIp
				vecesNueva = count(platform.subscribers[pos].ips.begin(), platform.subscribers[pos].ips.end(), ip);
				vecesMain = count(platform.subscribers[pos].ips.begin(), platform.subscribers[pos].ips.end(), platform.subscribers[pos].mainIp);
				if(vecesNueva > vecesMain){
					platform.subscribers[pos].mainIp = ip;
				}			
			}
		}
	}
}

void deleteSubscriber(Platform &platform) {
	string s_id;	
	int id, pos;

	cout << "Enter subscriber id: ";
	getline(cin, s_id);
	if(!s_id.empty()){
		id = stoi(s_id);
		pos = searchId(platform.subscribers, id);
		if(pos == -1){
			error(ERR_ID);
		}	
		else{
			platform.subscribers.erase(platform.subscribers.begin() + pos);
		}
	}
	else{
		error(ERR_ID);
	}
}

void importFromCsv(Platform &platform) {

}


// POR SI QUEREIS USAR UNA FUNCION AUXILIAR PARA EXPORTAR EL SUBSCRIBER.
void exportSuscriber(Subscriber sub, ofstream &fich){

}

void exportToCsv(const Platform &platform) {
	string filename;
	ofstream fich;

	cout << "Enter filename: ";
	getline(cin, filename);
	// c_str() devuelve un vector de caracteres con el contenido
	// del string.	
	fich.open(filename.c_str());
	if(fich.is_open()){
		for(Subscriber sub : platform.subscribers){
			fich << sub.name << ":" << sub.email << ":";
			for(int i = 0; i < sub.ips.size(); i++){
				fich << sub.ips[i];
				if(i != sub.ips.size() - 1){
					fich << "|";
				}
			}
			fich << endl;
		}
		fich.close();
	}
	else{
		error(ERR_FILE);
	}
}

void loadData(Platform &platform) {
}

void saveData(const Platform &platform) {
}

void importExportMenu(Platform &platform) {
}

int main(int argc, char *argv[]) {
  Platform platform;
  platform.name = "Streamflix";
  platform.nextId = 1;

  char option;
  do {
    showMainMenu();
    cin >> option;
    cin.get();

    switch (option) {
      case '1':
        showSubscribers(platform);
        break;
      case '2':
        addSubscriber(platform);
        break;
      case '3':
        addSubscriberIp(platform);
        break;
      case '4':
        deleteSubscriber(platform);
        break;
      case '5':
        importExportMenu(platform);
        break;
      case 'q':
        break;
      default:
        error(ERR_OPTION);
    }
  } while (option != 'q');

  return 0;
}
