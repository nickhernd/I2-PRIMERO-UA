#include <iostream>
using namespace std;

int main(){
	string cadena;
	int pos, veces;
	char car;

	// 1. Pedid una cadena de caracteres.
	cout << "cadena: ";
	getline(cin, cadena);

	// 2. Pedid un caracter.
	cout << "caracter: ";
	cin >> car;	

	// 3. Mostrad la cantidad de veces que el caracter esta en la cadena.
	veces = 0;
	for(int i = 0; i < cadena.length(); i++){
		if(cadena[i] == car){
			veces++;
		}
	}
	cout << "Cantidad de veces: " << veces << endl;

	// 4. Mostrad la posicion de la primera vez que aparece el caracter
	// en la cadena.
	pos = -1;
	for(int i = 0; i < cadena.length() && pos == -1; i++){
		if(cadena[i] == car){
			pos = i;
		}
	}
	if(pos == -1){
		cout << "No esta el caracter en la cadena" << endl;
	}
	else{
		cout << "La primera posicion donde aparec es "<< pos << endl;
		// 5. Separar la cadena en dos trozos, todo lo que hay a la izquierda
		// de pos y todo lo que hay a la derecha.
		string pIzquierda, pDerecha;
		pIzquierda = "";
		for(int i = 0; i < pos; i++){
			pIzquierda += cadena[i];
		}
		pDerecha = "";
		for(int i = pos + 1; i < cadena.length; i++){
			pDerecha += cadena[i]; // pDerecha = pDerecha + cadena[i];
		}
		// 6. Commprobar que la parte izquierda solo son letras
		cout << "parte izquierda: " << pIzquierda << endl;
		

		// 7. Comprobar que la parte derecha solo son digitos.
		cout << "parte derecha: " << pDerecha << endl;
		
	}




	return 0;
}
