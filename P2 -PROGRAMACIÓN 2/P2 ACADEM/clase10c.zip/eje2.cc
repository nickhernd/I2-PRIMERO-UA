#include <iostream>
#include <vector>
using namespace std;

struct Subscriber{
	string name, email, mainIp;
	vector<string> ips;
};


int main(){
	string info = "nico:ludonico@888.com:127.0.0.1:13|34|344|2|34|89";
	string auxip;
	Subscriber sus;
	int i, tam;

	// tenemos que meter la informacion de la cadena en la estructura
	// subscriber...
	
	sus.name = "";
	// bucle para concatenar todos los caracteres del name...
	i = 0;
	while(info[i] != ':'){
		sus.name = sus.name + info[i];
		i++;
	}
	cout << "Name: " << sus.name << endl;
	
	// me salto los :
	i++; 
	sus.email = "";
	while(info[i] != ':'){
		sus.email = sus.email + info[i];
		i++;
	}
	cout << "Email: " << sus.email << endl;

	// me salto los :
	i++;
	sus.mainIp = "";
	while(info[i] != ':'){
		sus.mainIp = sus.mainIp + info[i];
		i++;
	}
	cout << "Mainip: " << sus.mainIp << endl;


	//            ii
	// info = "...:13|34|344|2|34|89";
	tam = info.length();
	i++;
	while(i < tam){
		auxip = "";
		while(i < tam && info[i] != '|'){
			auxip = auxip + info[i];
			i++;
		}
		sus.ips.push_back(auxip);
		i++; // me salto la | 
	}
	
	for(int i = 0; i < sus.ips.size(); i++){
		cout << sus.ips[i] << " ";
	}
	cout << endl;


	return 0;
}
