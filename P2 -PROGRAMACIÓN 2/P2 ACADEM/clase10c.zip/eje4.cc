#include <iostream>
#include <sstream>
#include <vector>
using namespace std;

struct Subscriber{
	string name, email, mainIp;
	vector<string> ips;
};

int main(){
	stringstream ss;	
	string info = "nico:ludonico@888.com:127.0.0.1:13|34|344|2|34|89";
	Subscriber sus;
	string auxip;	

	ss << info;
	// como leo hasta los : del buffer.
	getline(ss, sus.name, ':');
	getline(ss, sus.email, ':');
	getline(ss, sus.mainIp, ':');

	do{	
		getline(ss, auxip, '|');
		sus.ips.push_back(auxip);
	}while(ss.eof() == false);
		
	
	cout << sus.name << endl;
	cout << sus.email << endl;
	cout << sus.mainIp << endl;
	for(int i = 0; i < sus.ips.size(); i++){
		cout << sus.ips[i] << " ";
	}
	cout << endl;
	

	return 0;
}
