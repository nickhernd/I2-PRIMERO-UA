#include <iostream>
#include <vector>
using namespace std;

int main(){
	// 	      iiii
	//            0123456789
	string cad = "   123   892    90144   323   ";
	string aux;
	int i, tam;
	vector<int> numeros;

	tam = cad.length();

	i = 0;
	while(i < tam){
		// se salta los espacios
		while(i < tam && cad[i] == ' '){
			i++; 
			// 0 -> 1 -> 2 -> 3
			// 6 -> 7 -> 8 -> 9
		}	
		// concatena todos digitos hasta que llegue a un espacio o al final	
		aux = "";
		while(i < tam && cad[i] != ' '){
			aux = aux + cad[i];
			cout << aux << " => ";
			i++;
			// 3 -> 4 -> 5 -> 6
			// 9 -> 10 -> 11 -> 12
		}
		cout << "[" << aux << "]" << endl;
		if(aux != ""){
			int valor = stoi(aux);	// string -> int		
			numeros.push_back(valor);
		}
	}
	
	cout << "{";
	for(int i = 0; i < numeros.size(); i++){
		cout << numeros[i];
		if(i != numeros.size() - 1){
			cout << ", ";
		} 
	}
	cout << "}";
	
	
	
	
	return 0;
}
