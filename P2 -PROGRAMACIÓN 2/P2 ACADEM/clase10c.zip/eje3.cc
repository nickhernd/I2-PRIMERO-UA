#include <iostream>
#include <sstream>
#include <vector>
using namespace std;


int main(){
	//            012345
	string cad = "  123  3455  99123  345512 34   ";
	stringstream buffer;
		
	buffer << cad;

	cout << buffer.str() << endl;

	cout << "por donde voy leyendo: " << buffer.tellg() << endl;
	cout << "por donde voy escribiendo: " << buffer.tellp() << endl;	
	
	buffer << 23;
	cout << buffer.tellp() << endl;	

	int entero;

	// se salta los espacios hasta encontar un digito
	// va guardando mientras sea un digito.
	//*******************
	buffer >> entero;
	cout << "He leido el entero " << entero << endl;
	cout << "despues de leer entero estoy en: " << buffer.tellg() << endl;
	

	cout << "cuantos caracteres quedan por leer: " << 				buffer.tellp() - buffer.tellg() << endl;
	
	// existe una funcion buffer.eof(), que devuelve true si
	// hemos intentado leer caracteres en el buffer y no quedan caracteres...
	int suma = 0;	
	buffer >> numero;
	while(buffer.eof() == false){
		suma = suma + numero;
		buffer >> numero;
	}
	cout << "la suma total es " << suma << endl;


	return 0;
}
