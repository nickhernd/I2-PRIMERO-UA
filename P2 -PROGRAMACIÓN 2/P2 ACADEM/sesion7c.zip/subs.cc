#include <iostream>
#include <vector>
using namespace std;

struct Subscriber {
  unsigned int id;
  string name;
  string email;
  string mainIp;
  vector<string> ips;
};

struct Platform {
  string name;
  vector<Subscriber> subscribers;
  unsigned int nextId;
};

void printSubscriber(Subscriber sub){
	cout << sub.id << ":";	
	cout << sub.name << ":";
	cout << sub.email << ":";
	cout << sub.mainIp << ":";
	for(int i = 0; i < sub.ips.size(); i++){
		cout << sub.ips[i];
		if(i != sub.ips.size() - 1){
			cout << "|";
		}
	}
}

void printSubscriber2(Subscriber sub){
	cout << sub.id << ":";	
	cout << sub.name << ":";
	cout << sub.email << ":";
	cout << sub.mainIp << ":";
	for(int i = 0; i < sub.ips.size(); i++){
		if(i != 0){
			cout << "|";
		}
		cout << sub.ips[i];
	}
}

void printSubscribers(Platform plt){
	for(int i = 0; i < plt.subscribers.size(); i++){
		printSubscriber(plt.subscribers[i]);
		cout << endl;
	}
}



int main(){
	Platform platform = {"sus12", {}, 1};
	char option;
	Subscriber sub;
	
	string s_id, ip;
	int id, pos;
	
	int cuantas, cuantasActual;

	do{
		cout << "1. add" << endl;
		cout << "2. show" << endl;
		cout << "3. add ip" << endl;
		cout << "4. delete" << endl;
		cout << "q. exit" << endl;
		cin >> option;
		cin.get();
		switch(option){
			case '1':
				cout << "Enter name: ";
				getline(cin, sub.name);
				cout << "Enter email: ";
				getline(cin, sub.email);
				sub.id = platform.nextId;
				sub.mainIp = "";
				platform.nextId++;
				platform.subscribers.push_back(sub);
			break;
			case '2':
				printSubscribers(platform);
			break;
			case '3':
				cout << "Enter subscriber id: ";
				getline(cin, s_id);
				if(s_id == ""){
					cout << "Error en id" << endl;
				}
				else{
					id = stoi(s_id);
					pos = -1;
					for(int i = 0; i < platform.subscribers.size() && pos == -1; i++){
						if(id == platform.subscribers[i].id){
							pos = i;
						}
					}
					if(pos == -1){
						cout << "Error en id" << endl;
					}
					else{
						cout << "Enter IP: " << endl;
						getline(cin, ip);
						platform.subscribers[pos].ips.push_back(ip);
					
						// cuantas veces se repite la mainIp.
						cuantas = 0;
						for(int i = 0; i < platform.subscribers[pos].ips.size(); i++){
							if(platform.subscribers[pos].ips[i] == platform.subscribers[pos].mainIp){
								cuantas++;
							}
						}

						// cuantas veces se repite la ip
						cuantasActual = 0;
						for(int i = 0; i < platform.subscribers[pos].ips.size(); i++){
							if(platform.subscribers[pos].ips[i] == ip){
								cuantasActual++;
							}
						}
						if(cuantasActual > cuantas){
							platform.subscribers[pos].mainIp = ip;
						}
						
					}
				}				
			break;
			case '4':
			break;
			case 'q':
			break;
			default:
				cout << "opcion incorrecta" << endl;
			break;
		}
	}while(option != 'q');

	return 0;
}
