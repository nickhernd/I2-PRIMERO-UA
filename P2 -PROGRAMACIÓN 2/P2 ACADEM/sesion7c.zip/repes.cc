#include <iostream>
#include <vector>
using namespace std;

int main(){
	string nombres[] = {"fatima", "ayoub", "ahmed", "zuhair", "mohamed"};
	vector<string> alumnos;
	int r, veces, posMayor;
	
	for(int i = 1; i <= 15; i++){
		r = rand() % 5; // 0 y 4
		alumnos.push_back(nombres[r]);
	}

	for(string n : alumnos){
		cout << n << " ";
	}
	cout << endl;

	int posMasVeces = -1;
	int vecesMayor = 0;
	for(int i = 0; i < alumnos.size(); i++){
		veces = 0;
		for(int j = 0; j < alumnos.size(); j++){
			cout << "i: " << i << " " <<alumnos[i] 				<< ",  j: " << j << " " << alumnos[j];
			if(alumnos[i] == alumnos[j]){
				veces++;
				cout << "*** " << veces;
			}
			cout << endl;
		}
		// compruebo si el actual se repite mas veces que el mayor
		// hasta ahora.
		if(veces > vecesMayor){
			vecesMayor = veces;
			posMayor = i;
			cout << "Actualizando mayor a " << posMayor << endl;
		}
		cout << alumnos[i] << " esta " << veces << "veces..." << endl;
	}
	cout << "El que mas veces se repite es " << alumnos[posMayor];
	cout << " y se repite " << vecesMayor << " veces." << endl;

	return 0;
}
