#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

/*
	Realiza un programa que pida el nombre de un fichero en el cual
	hay puntuaciones de jugadores, el programa deberá mostrara para cada
	jugador su puntuacion final.

	---------------------------------------
	jugador 1:12
	jugador 2:34
	jugador 1:18
	jugador 2:2
	jugador 1:9
	jugador 2:11
	jugador 3:2
	-------------------------------------- 

	jugador 1 gano 39
	jugador 2 gano 47
	jugador 3 gano 2
	
	el campeon es jugador 2.
*/
struct Jugador{
	string id;
	int puntos;
};
void insertUpdate(vector<Jugador> &jugadores, string nombre, int puntos){
	// lo busco si esta le añado los puntos si no esta
	// lo añado al vector con esos puntos
	int pos, i;
	pos = -1;
	for(i = 0; i < jugadores.size() && pos == -1; i++){
		if(jugadores[i].id == nombre){
			pos = i;
		}
	}
	if(pos != -1){
		jugadores[pos].puntos += puntos;
	}
	else{
		Jugador jugador = {nombre, puntos};
		jugadores.push_back(jugador);
	}
}
int main(){
	vector<Jugador> jugadores;
	string filename, nombre;
	int puntos;
	ifstream fich;

	cout << "Enter filename: ";
	getline(cin, filename);
	fich.open(filename.c_str());
	if(fich.is_open()){
		getline(fich, nombre, ':');
		while(!fich.eof()){
			fich >> puntos;
			fich.get();
			///////////////////////
			insertUpdate(jugadores, nombre, puntos);			
			///////////////////////
			getline(fich, nombre, ':');
		}
		fich.close();
	}
	else{
		cout << "Error cannot opoen file" << endl;
	}

	return 0;
}
