#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

/*
	Realiza un programa que lea palabras de un fichero y muestre por pantalla,
	las palabras que hay en el fichero sin repetidos. Se considerará una 
	palabra cualquier secuencia de caracteres separada por espacios.

	"filename.txt"
	---------------------------------
	    javi      jose   jose jose
         donde    estas    jose
           josemi josemi josemi
	---------------------------------
	
	mostrará
		javi
		jose
		donde
		estas
		josemi
*/
bool search(vector<string> palabras, string palabra){
	bool found = false;
	for(int i = 0; i < palabras.size() && found == false; i++){
		if(palabra == palabras[i]){
			found = true;
		}
		/*else{
			found = false;
		}*/
	}
	return found;
}

int main(){
	vector<string> cadenas;
	string filename, palabra;
	ifstream fich;
	bool found;
	
	cout << "Enter filename: ";
	getline(cin, filename);
	fich.open(filename.c_str());
	if(fich.is_open()){
		fich >> palabra;
		while(fich.eof() == false){
			if(search(cadenas, palabra) == false){
				cadenas.push_back(palabra);
			}		
			fich >> palabra;
		}
		fich.close();
		for(string pal : cadenas){
			cout << pal << endl;
		}
	}
	else{
		cout << "ERROR: Cannot open file" << endl;
	}	


	return 0;
}
