#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

/*
- Realiza un programa que lea un fichero de texto cuyo nombre lo introduce el usuario
y muestre por pantalla, para cada palabra que aparece en el fichero y en el orden en
el que aparecen, la palabra y la cantidad de veces que aparece en el fichero. 
*/
struct Info{
	string palabra;
	int veces;
};
void insertUpdateSacred(vector<Info> &palabras, string palabra){
	// busco la palabra en palabras...
	int pos, i;
	pos = -1;
	for(i = 0; i < palabras.size() && pos == -1; i++){
		if(palabras[i].palabra == palabra){
			pos = i;
		}
	}
	if(pos != -1){	// si ya esta en pos
		palabras[pos].veces++;
	}
	else{
		Info info = {palabra, 1};
		palabras.push_back(info);
	}
}
int main(){
ifstream fich;
	vector<Info> palabras;
	Info info;
	string filename, palabra;
	// pedid el nombre del fichero.
	cout << "Enter filename: ";
	getline(cin, filename);
	// abrir el fichero
	fich.open(filename.c_str());
	// comprobar si se ha abierto
	if(fich.is_open()){
	//	leer el fichero palabra a palabra
		fich >> palabra;
		while(!fich.eof()){
	//		y para cada palabra
			insertUpdateSacred(palabras, palabra);
	//		si ya esta en el vector de palabras
	//			incremento las veces
	//		si no esta
	//			la meto al final como nueva.
			fich >> palabra;
		}	
	//	cierro el fichero
		fich.close();
		for(int i = 0; i < palabras.size(); i++){
			cout << palabras[i].palabra << " "
				<< palabras[i].veces << endl;
		}
	}
	else{
		cout << "Error al abrir el fichero" << endl;
	}	

	return 0;
}
