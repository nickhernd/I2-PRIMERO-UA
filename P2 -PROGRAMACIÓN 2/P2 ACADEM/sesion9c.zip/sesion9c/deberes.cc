#include <string>
#include <iostream>
#include <cctype>
using namespace std;

// al menos 3 caracteres
// y no contiene el caracter : 
bool testName(string name){
	int tam;
	bool valido;

	tam = name.length();
	if(tam < 3){
		valido = false;
	}
	else{
		valido = true;
		if(name.find(':') != string::npos){
			valido = false;
		}
	}
	return valido;
}

bool testNameMio(string name){
	int tam;
	bool valido = false;

	if(tam >= 3){
		if(name.find(':') != string::npos){
			valido = true;
		}
	}
	return valido;
}

bool testNamePro(string name){
	return name.length() >= 3 && name.find(':') == string::npos;
}



/*
	 Devuelve si el caracter esta o no en la cadena.
*/
bool search(string cad, char c){
	bool encontrado;
	if(cad.find(c) == string::npos){
		encontrado = false;
	}
	else{
		encontrado = true;
	}
	return encontrado;
/*	bool encontrado = false;
	int i;
	for(i = 0; i < cad.length() && encontrado == false; i++){
		if(cad[i] == c){
			encontrado = true;
		}
	}
	return encontrado;*/
}

/*
	 Devuelve la posicion donde esta el caracter en la cadena.
	 -1 si no esta en la cadena.
*/
int searchPos(string cad, char c){
	int i, pos;
	pos = -1;
	for(i = 0; i < cad.length() && pos == -1; i++){
		if(cad[i] == c){
			pos = i;
		}
	}
	return pos;
/*	int pos;
	if(cad.find(c) == string::npos){
		pos = -1;
	}
	else{
		pos = cad.find(c);
	}
	return pos;*/
}

/*
	Devuelve cierto si la longitud esta entre 4 y 10
	y todos los caracteres son letras minusculas.
*/
bool cmpName(string n){
	bool valido = false;
	int tam, i;
	tam = n.length();
	if(tam >= 4 && tam <= 10){
		// si tengo que comprobar que todos los elementos
		// cumplen una condicion:
		valido = true; // *** supongo que todos lo cumplen
		for(i = 0; i < tam && valido == true; i++){
			if(islower(n[i]) == 0){
				// busco uno que no lo cumpla ^^
				valido = false;
			}
		}
	}
	return valido;
}

// 7 caracteres los 4 primeros digitos y los 3 ultimos son 
// consontantes en mayusculas.
bool cmpMatricula(string mat){
	bool valido = false;
	int tam;
	string vocales = "AEIOU";

	tam = mat.length();
	if(tam == 7){
		valido = true;
		for(int i = 0; i < 4 && valido == true; i++){
			if(isdigit(mat[i]) == 0){
				valido = false;
			}
		}
		for(int i = 4; i < tam && valido == true; i++){
			if(isupper(mat[i]) == 0 || vocales.find(mat[i]) != string::npos){
				valido = false;
			}
		}
	}
	return valido;
}

/*
	Devuelve cierto si solo contiene digitos,
	es decir caracteres nuemricos

	31413241
	3214a2342 NO
*/
bool onlyDigits(string n){
	bool valido;
	int i, tam;
	tam = n.length();
	if(tam == 0){
		valido = false;
	}
	else{
		valido = true;
		for(i = 0; i < tam && valido == true; i++){
			if(isdigit(n[i]) == 0){
				valido = false;
			}
		}
	}
	return valido;
}
/*
	letras, digitos o el caracter subrayado y no puede empezar por digito.
		alumno3 => OK
		_alumno => OK
		3alumno => NOK
*/
bool isVariableName(string name){
	bool valido;
	int tam, i;

	tam = n.length()
	if(tam > 0){
		if(isdigit(n[0]) != 0){
			valido = false;
		} 
		else{
			valido = true;
			for(int i = 0; i < tam && valido == true; i++){
				if(name[i] != '_' && isalnum(name[i]) == 0){
					valido = false;
				}
			}
		}
	}
	else{
		valido = false;
	}
	return valido;
}


/*
	Devuelve cierto si la cadena tiene dos partes
	una en la que todo son digitos y luego otra en
	la que todo son letras, cualquier parte puede estar
	vacia:
		123321asdfasfda
		afddsfasdf
		234324
		=> 132addfa12313
*/

bool twoFaces(string n){

}

// devuelve cierto si todos los caracteres de la cadena n
// aparecen en el conjunto de caracteres charset
//	validCharset("134aa", "1234556789abc") => true
//	validCharset("134aaz", "1234556789abc") => false
bool validCharset(string n, string charset){
	
}


// no puede estar vacia...
// los caracteres validos son: letras numeros . _
bool testParte(string parte){
	bool valido = false;
	int tam, i;

	tam = parte.length();
	if(tam > 0){ // if(parte != "") // if(parte.empty() == false)
		if(parte[0] != '.' && parte[tam-1] != '.'){
			valido = true;
			for(i = 0; i < tam && valido; i++){
				if(isalnum(parte[i]) == 0 && parte[i] != '.' && parte[i] != '_'){
					valido = false;	
				}
			}
		}
	}	
	return valido;
}


bool validateEmail(string email){
	bool valid;
	string izq, der;
	int i;
	// partimos la cadena en dos trozos
	//		- uno que va hasta la @
	//  	- otro que va desde la @ hasta el final

	izq = "";
	i = 0;
	while(i < email.length() && email[i] != '@'){
		izq = izq + email[i];
		i++;
	}
	i++; // me salto la @
	der = "";
	while(i < email.length()){
		der = der + email[i];
		i++;
	}
	if(testParte(izq) && testParte(der) && der.find('.') != string::npos){
		valid = true;
	}

	return valid;
}


bool validateEmail(string email){
	bool valid = false;
	string izq, der;
	int i;
	// partimos la cadena en dos trozos
	//		- uno que va hasta la @
	//  	- otro que va desde la @ hasta el final
	i = email.find('@');
	if(i != string::npos){
		izq = email.substr(0, i);
		der = email.substr(i+1); // hasta el final...
		
	}
	
	return valid;
}





int main(){
	cout << isupper('A') << endl;
	cout << isdigit('0') << endl;
	
	cout << isupper('a') << endl;
	cout << isdigit('a') << endl;
	
	char c = '8';
	cout << (c >= '0' && c <= '9') << endl; // isdigit(c)
	cout << (c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z') << endl; // isalpha(c)	

	if(onlyDigits("") == false){
		cout << "numero incorrecto" << endl;
	}

}






