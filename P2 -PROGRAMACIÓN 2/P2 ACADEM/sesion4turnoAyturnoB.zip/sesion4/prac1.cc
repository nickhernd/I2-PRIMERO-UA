/*
	QUE ES LO MINIMO QUE TENGO QUE TENER PARA EL LUNES O VOY A SUSPENDER LA PRIMERA PRACTICA....

	LEER EL PLAYER
	CREAR NIVELES (SIN COMPROBAR NINGUN ERROR DE OBSTACULOS)
	MOSTRAR NIVELES

*/


#include <iostream>
#include <cstring>
#include <vector>
using namespace std;

const int KNAME=40;
const int KMAXOBSTACLES=20;

const int KMAXLEVELS = 10;

enum Error{
    ERR_OPTION,
    ERR_DIFFICULTY,
    ERR_LEVEL,
    ERR_COORDINATE,
    ERR_OBSTACLES,
    ERR_ID,
    ERR_INSTRUCTION
};

// Registro para las coordenadas
struct Coordinate{
    int row;
    int column;
};

// Registro para el jugador
struct Player{
    char name[KNAME];
    int difficulty;
    int score;
    int wins;
    int losses;
};

// Registro para el nivel
struct Level{
    int id;
    int size;
    int numObstacles;
    Coordinate obstacles[KMAXOBSTACLES];
    Coordinate start;
    Coordinate finish;
};

// Función que muestra los mensajes de error
void error(Error e){
    switch(e){
        case ERR_OPTION: cout << "ERROR: wrong option" << endl;
            break;
        case ERR_DIFFICULTY: cout << "ERROR: wrong difficulty" << endl;
            break;
        case ERR_LEVEL: cout << "ERROR: cannot create level" << endl;
            break;
        case ERR_COORDINATE: cout << "ERROR: wrong coordinate" << endl;
            break;
        case ERR_OBSTACLES: cout << "ERROR: wrong number of obstacles" << endl;
            break;
        case ERR_ID: cout << "ERROR: wrong id" << endl;
            break;
        case ERR_INSTRUCTION: cout << "ERROR: wrong instruction" << endl;
            break;
    }
}

// Función que muestra el menú de opciones
void showMenu(){
    cout << "[Options]" << endl
        << "1- Create level" << endl
        << "2- Delete level" << endl
        << "3- Show levels" << endl
        << "4- Play" << endl
        << "5- Report" << endl
        << "q- Quit" << endl
        << "Option: ";
}

int readDifficulty(){
	int d;
	do{
		cout << "Difficulty: ";
		cin >> d;
		cin.get();
		if(d < 1 || d > 3){
			error(ERR_DIFFICULTY);
		}
	}while(d < 1 || d > 3);
	return d;
}

void readPlayer(Player &player){
	cout << "Name: ";
	cin.getline(player.name, KNAME);
	player.difficulty = readDifficulty();
	player.score = player.wins = player.losses = 0;
}


void showLevel(Level level){
	int k;
	bool encontrado;
	cout << "Level " << level.id << endl;
	for(int i = 0; i < level.size; i++){
		for(int j = 0; j < level.size; j++){
			if(i == level.start.row && j == level.start.column){
				cout << "R ";
			}
			else{
				if(i == level.finish.row && j == level.finish.column){
					cout << "F ";	
				}
				else{
						encontrado = false;
						for(int k = 0; k < level.numObstacles && encontrado == false; k++){
							if(level.obstacles[k].row == i && level.obstacles[k].column == j){
								encontrado = true;
							}
						}	
						if(encontrado == true){
							cout << "X ";
						}
						else{
							cout << "O ";
						}
				}
			}
		}
		cout << endl;
	}
}

bool comprobar(Coordinate obstacles[], int numObstacles, Level level){
	bool correcto = true;

	// buscamos alguna coordenada que se salga del tablero.
	for(int i = 0; i < numObstacles && correcto == true; i++){
		if(obstacles[i].row >= level.size || obstacles[i].column >= level.size){
			correcto = false;


		}
	}

	// buscamos alguna coordenada que sea igual a start o finish.	
	for(int i = 0; i < numObstacles && correcto == true; i++){
		if(level.start.row == obstacles[i].row && level.start.column == obstacles[i].column || 
			level.finish.row == obstacles[i].row && level.finish.column == obstacles[i].column){
			correcto = false;
		}
	}
	// son iguales entre elllas.
	for(int i = 0; i < numObstacles && correcto == true; i++){
		for(int j = i + 1; j < numObstacles && correcto == true; j++){
			if(obstacles[i].row == obstacles[j].row && obstacles[i].column == obstacles[j].column){
				correcto = false;
			}
		}
	}
	// son adyacentes entre ellas.
	for(int i = 0; i < numObstacles && correcto == true; i++){
		for(int j = i + 1; j < numObstacles && correcto == true; j++){
				if(abs(obstacles[i].row - obstacles[j].row) <= 1 && abs(obstacles[i].column - obstacles[j].column) <= 1){
					correcto = false;
				}
		}
	}
	return correcto;
}

void readObstaclesForNoobs(Level &nl){
	int k = 0;
	char linea[100];
	
	cout << "Obstacles: ";
	cin.getline(linea, 100);
	int row, column;
	for(int i = 0; i < strlen(linea); i = i + 4){
		row = linea[i] - '0'; // '2' - '0' => 2
		column = linea[i+2] - '0';
		nl.obstacles[k] = {row, column};
		k++;
	}
	nl.numObstacles = k;
	showLevel(nl);
}

void readObstacles(Level &nl){
	char linea[100];
	int row, column, k;
	bool correcto;
	int maxObstacles;

	switch(nl.size){
		case 5:	maxObstacles = 5; break;
		case 7: maxObstacles = 10; break;
		case 10: maxObstacles = 20; break;
	}
	do{
		correcto = true;
		cout << "Obstacles: ";
		cin.getline(linea, 100);
		// i   i
		// 0 2 4
		// 2,4|4,5|3,1
		k = 0;	
		for(int i = 0; i < strlen(linea) && correcto == true; i = i + 4){
			if(k == maxObstacles){
				correcto = false;
			}
			else{
				row = linea[i] - '0'; // '2' - '0' => 2
				column = linea[i+2] - '0';
				nl.obstacles[k] = {row, column};
				k++;
			}
		}
		nl.numObstacles = k;
		if(correcto){
			correcto = comprobar(nl.obstacles, k, nl);
			if(correcto == false){
				error(ERR_COORDINATE);
			}
		}
		else{
			error(ERR_OBSTACLES);
		}
	}while(correcto == false);
	showLevel(nl);
}

void createLevel(vector<Level> &levels, int &numLevels, int d){
	Level newLevel;
	if(levels.size() < KMAXLEVELS){
		newLevel.id = numLevels + 1;
		numLevels++;
		switch(d){
			case 1:
				newLevel.size = 5;
			break;
			case 2:
				newLevel.size = 7;
			break;
			case 3:
				newLevel.size = 10;
			break;
		}
		newLevel.start = {newLevel.size - 1, 0};
		newLevel.finish = {0, newLevel.size - 1};
		readObstaclesForNoobs(newLevel);
		levels.push_back(newLevel);
	}
	else{
		error(ERR_LEVEL);
	}
}


void report(Player player){
	int total;

	total = player.wins + player.losses;
	cout << "[Report]" << endl;
	cout << "Name: " << player.name << endl;
	
	cout << "Difficulty: ";;
	switch(player.difficulty){
		case 1:
			cout <<"Easy" << endl;
			break;
		case 2:
			cout <<"Medium" << endl;	
			break;
		case 3:
			cout << "Hard" << endl;
			break;
	}
	cout << "Score: " << player.score << endl;
	cout << "Wins: " << player.wins << endl;
	cout << "Losses: " << player.losses << endl;
	cout << "Total: " << total << endl;
}


void deleteLevel(vector<Level> &levels){
	int id;
	char res;
	int pos;

	cout << "Id: ";
	cin >> id;
	cin.get();

	// buscamos la posicion del nivel cuyo id es el id que acaba
	// de introducir el usuario.
	pos = -1;
	for(int i = 0; i < levels.size() && pos == -1; i++){
		if(id == levels[i].id){
			pos = i;
			// levels.erase(levels.begin() + pos);
		}
	}
	if(pos == -1){
		error(ERR_ID);
	}
	else{
		// preguntamos al usuario si lo quiere eliminar.
		do{	
			cout << "Are you sure? [y/n] ";
			cin >> res;
		}while(res != 'y' && res != 'Y' && res != 'n' && res != 'N');
		if(res == 'y' || res == 'Y'){
			levels.erase(levels.begin() + pos);
		}
	}
	
}

void showLevels(vector<Level> levels){
	for(int i = 0; i < levels.size(); i++){
		showLevel(levels[i]);
	}
}

void playLevel(vector<Level> levels, Player p){
	int id, pos;
	char linea[100];

	cout << "Id: ";
	cin >> id;
	cin.get();
	pos = -1;
	for(int i = 0; i < levels.size() && pos == -1; i++){
		if(id == levels[i].id){
			pos = i;
			// levels.erase(levels.begin() + pos);
		}
	}
	if(pos == -1){
		error(ERR_ID);
	}
	else{
		showLevel(levels[pos]);
		Level actual = levels[pos];
		cout << "Instructions: ";
		cin.getline(linea, 100);
		for(int i = 0; i < strlen(linea); i++){
			cout << "Instruction: " << linea[i] << endl;			
			switch(linea[i]){
				case 'U':
					actual.start.row--;
				break;
				case 'D':
					actual.start.row++;
				break;
				case 'R':
					actual.start.column++;
				break;
				case 'L':
					actual.start.column--;
				break;
			}
			showLevel(actual);
		}
	}
}

// Función principal (tendrás que añadirle más código tuyo)
int main(){
    char option;
    Player player;
	vector<Level> levels;
	int numLevels = 0;

	readPlayer(player);
    do{
        showMenu();
        cin >> option;
        cin.get(); // Para evitar que el salto de línea se quede en el buffer de teclado y luego pueda dar problemas si usas "getline"
        switch(option){
            case '1': // Llamar a la función para crear un nuevo nivel
				createLevel(levels, numLevels, player.difficulty);
                break;
            case '2': // Llamar a la función para borrar un nivel existente
				deleteLevel(levels); 
               break;
            case '3': // Llamar a la función para mostrar los niveles creados
				showLevels(levels);
                break;
            case '4': // Llamar a la función para jugar
				playLevel(levels, player);
                break;
            case '5': // Llamar a la función para mostrar información del jugador
				report(player);
                break;
            case 'q': break;
            default: error(ERR_OPTION); // Muestra "ERROR: wrong option"
        }
    }while(option!='q');
}

