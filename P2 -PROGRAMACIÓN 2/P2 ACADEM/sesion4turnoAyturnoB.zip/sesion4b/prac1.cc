#include <iostream>
#include <vector>
#include <cstring>
using namespace std;

const int KNAME=40;
const int KMAXOBSTACLES=20;

enum Error{
    ERR_OPTION,
    ERR_DIFFICULTY,
    ERR_LEVEL,
    ERR_COORDINATE,
    ERR_OBSTACLES,
    ERR_ID,
    ERR_INSTRUCTION
};

// Registro para las coordenadas
struct Coordinate{
    int row;
    int column;
};

// Registro para el jugador
struct Player{
    char name[KNAME];
    int difficulty;
    int score;
    int wins;
    int losses;
};

// Registro para el nivel
struct Level{
    int id;
    int size;
    int numObstacles;
    Coordinate obstacles[KMAXOBSTACLES];
    Coordinate start;
    Coordinate finish;
};

// Función que muestra los mensajes de error
void error(Error e){
    switch(e){
        case ERR_OPTION: cout << "ERROR: wrong option" << endl;
            break;
        case ERR_DIFFICULTY: cout << "ERROR: wrong difficulty" << endl;
            break;
        case ERR_LEVEL: cout << "ERROR: cannot create level" << endl;
            break;
        case ERR_COORDINATE: cout << "ERROR: wrong coordinate" << endl;
            break;
        case ERR_OBSTACLES: cout << "ERROR: wrong number of obstacles" << endl;
            break;
        case ERR_ID: cout << "ERROR: wrong id" << endl;
            break;
        case ERR_INSTRUCTION: cout << "ERROR: wrong instruction" << endl;
            break;
    }
}

// Función que muestra el menú de opciones
void showMenu(){
    cout << "[Options]" << endl
        << "1- Create level" << endl
        << "2- Delete level" << endl
        << "3- Show levels" << endl
        << "4- Play" << endl
        << "5- Report" << endl
        << "q- Quit" << endl
        << "Option: ";
}

void readPlayer(Player &player){
	cout << "Name: ";
	cin.getline(player.name, KNAME);
	do{
		cout << "Difficulty: ";
		cin >> player.difficulty;
		cin.get();
		if(player.difficulty < 1 || player.difficulty > 3){
			error(ERR_DIFFICULTY);
		}
	}while(player.difficulty < 1 || player.difficulty > 3);
	player.wins = player.losses = player.score = 0;
}


//		   i i i
//         0123456789
// linea = 0,4|3,0|7,1
void readObstacles(Level &level, int maxObstacles){
	char linea[100];
	int tam, i;
	Coordinate nueva;

	cout << "Obstacles: ";
	cin.getline(linea, 100);

	tam = strlen(linea);
	i = 0; 
	level.numObstacles = 0;
	while(i < tam){
		nueva.row = linea[i] - '0';
		i = i + 2;
		nueva.column = linea[i] - '0'; 
		i = i + 2;
		level.obstacles[level.numObstacles] = nueva;
		level.numObstacles++;	
	}

}


void showLevel(Level level){
	for(int i = 0; i < level.size; i++){
		for(int j = 0; j < level.size; j++){
			if(i == level.start.row && j == level.start.column){
				cout << "R";
			}
			else{
				if(i == level.finish.row && j == level.finish.column){
					cout << "F";
				}
				else{			
					bool encontrado = false;
					for(int k = 0; k < level.numObstacles; k++){
						if(i == level.obstacles[k].row && j == level.obstacles[k].column){
							encontrado = true;
						}
					}
					if(encontrado == true){
						cout << "X";
					}
					else{
						cout << "O";
					}
				}
			}
		}
		cout << endl;
	}
}

void showLevels(vector<Level> levels){
	for(int i = 0; i < levels.size(); i++){
		cout << "Level " << levels[i].id << endl;
		showLevel(levels[i]);
	}
}

void createLevel(vector<Level> &levels, int &numLevels, int d){
	Level level;
	int maxObstacles;

	if(numLevels == 10){
		error(ERR_LEVEL);
	}
	else{
		level.id = numLevels + 1;
		numLevels++;
		switch(d){
			case 1: level.size = 5; maxObstacles = 5;  break;
			case 2: level.size = 7; maxObstacles = 10; break;
			case 3: level.size = 10; maxObstacles = 20; break;
		}
		level.start.row = level.size - 1;
		level.start.column = 0;
		level.finish.row = 0;
		level.finish.column = level.size - 1;
		readObstacles(level, maxObstacles);
		cout << "Level " << level.id << endl;
		showLevel(level);
		levels.push_back(level);		
	}
}

void report(Player player){
	cout << "[Report]" << endl;
	cout << "Name: " << player.name << endl;
	cout << "Difficulty: ";
	switch(player.difficulty){
		case 1: cout << "Easy" << endl; break;
		case 2: cout << "Medium" << endl; break;
		case 3: cout << "Hard" << endl; break;
	}
	cout << "Score: " << player.score << endl;
	cout << "Wins: " << player.wins << endl;
	cout << "Losses: " << player.losses << endl;
	cout << "Total: " << player.wins + player.losses << endl;
}

// devuelve -1 si no encuetnra ningun level con el id pasado como parametrooo.
int buscarLevel(vector<Level> levels, int id){
	int pos;

	pos = -1;
	for(int i = 0; i < levels.size() && pos == -1; i++){
		if(levels[i].id == id){
			pos = i;
		}
	}
	return pos;
}

void deleteLevel(vector<Level> &levels){
	int id, pos;
	char r;

	cout << "Id: ";
	cin >> id;
	cin.get();
	pos = buscarLevel(levels, id);
	if(pos == -1){
		error(ERR_ID);
	}
	else{
		do{
			cout << "Are you sure? [y/n] ";
			cin >> r;
			cin.get();
		}while(r != 'y' && r != 'Y' && r != 'n' && r != 'N');
		if(r == 'y' || r == 'Y'){
			levels.erase(levels.begin() + pos);
		}
	}
}

void play(vector<Level> levels, Player &player){
	int id, pos, i, points;
	char linea[100];
	bool errorc;	

	cout << "Id: ";
	cin >> id;
	cin.get();
	pos = buscarLevel(levels, id);
	if(pos == -1){
		error(ERR_ID);
	}
	else{
		cout << "Level " << levels[pos].id << endl;
		showLevel(levels[pos]);
		Level juego = levels[pos];
		cout << "Instructions: ";
		cin.getline(linea, 100);
		i = 0;
		errorc = false;
		while(linea[i] != '\0' && errorc == false){
			switch(linea[i]){
				case 'U':
					juego.start.row--; 
				break;
				case 'D':
					juego.start.row++;
				break;
				case 'L':
					juego.start.column--;
				break;
				case 'R':
					juego.start.column++;
				break;
				default:
					errorc = true;
					break;
			}
			// compruebo que no me he salido del mapa
			if(juego.start.row < 0 || juego.start.row >= juego.size || juego.start.column < 0 || juego.start.column >= juego.size){
				errorc = true;
			}
			// que no he caido dentro encima de un obstaculo
			bool encontrado = false;
			for(int k = 0; k < juego.numObstacles && encontrado == false; k++){
				if(juego.obstacles[k].row == juego.start.row && juego.obstacles[k].column == juego.start.column){
					encontrado = true;
				}
			}
			if(encontrado == true){
				errorc = true;
			}	
			if(errorc == false){
				cout << "Instruction " << linea[i] << endl;			
				showLevel(juego);
				i++;
			}
		}
		if(errorc == true){
			error(ERR_INSTRUCTION);
			player.losses++;
			cout << "You lose" << endl;
		}
		else{
			// compruebo si estoy en la coordenada final
			if(juego.start.row == juego.finish.row && juego.start.column == juego.finish.column){
				points = 3 * (juego.size - 1) - strlen(linea);
				cout << "You win " << points << " points" << endl;
				player.score += points;
				player.wins++;			
			}
			else{
				player.losses++;
				cout << "You lose" << endl;
			}
		}
	}
}

// Función principal (tendrás que añadirle más código tuyo)
int main(){
    char option;
	Player player;
	vector<Level> levels;
	int numLevels = 0;


	readPlayer(player);    
    do{
        showMenu();
        cin >> option;
        cin.get(); // Para evitar que el salto de línea se quede en el buffer de teclado y luego pueda dar problemas si usas "getline"
        
        switch(option){
            case '1': // Llamar a la función para crear un nuevo nivel
				createLevel(levels, numLevels, player.difficulty);                
				break;
            case '2': // Llamar a la función para borrar un nivel existente
				deleteLevel(levels);
                break;
            case '3': // Llamar a la función para mostrar los niveles creados
				showLevels(levels);
                break;
            case '4': // Llamar a la función para jugar
				play(levels, player);
                break;
            case '5': // Llamar a la función para mostrar información del jugador
				report(player);
                break;
            case 'q': break;
            default: error(ERR_OPTION); // Muestra "ERROR: wrong option"
        }
    }while(option!='q');
}
