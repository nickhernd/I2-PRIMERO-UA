#include <iostream>
#include <vector>
using namespace std;


int main(){
	// Creamos un vector de enteros.
	vector<int> enteros;
	int valor;

	// Rellenamos el vector de enteros con 10 valores introducidos por el 
	// usuario.
	for(int i = 1; i <= 10; i++){
		cout << "valor: ";
		cin >> valor;
		enteros.push_back(valor);
	}
	for(int i = 0; i < enteros.size(); i++){
		cout << enteros[i] << " ";
	}
	cout << endl;

	// Pedimos un valor y mostramos las posiciones donde aparece en el vector
	cout << "Valor a buscar? ";
	cin >> valor;
	for(int i = 0; i < enteros.size(); i++){
		if(valor == enteros[i]){
			cout << "encontrado en la posicion " << i << endl;
		}
	}
	
	// Pedimos un valor y mostramos solo la primera posicion donde aparece
	// en el vector.
	cout << "Valor a buscar? ";
	cin >> valor;
	int pos;
	pos = -1;
	for(int i = 0; i < enteros.size() && pos == -1; i++){
		if(valor == enteros[i]){
			pos = i;
		}
	}
	if(pos == -1){
		cout << "No hemos encontrado el valor" << endl;
	}
	else{
		cout << "Primera posicion donde aparece: " << pos << endl;
	}
	/*int i;
	i = 0;
	pos = -1;
	while(i < enteros.size() && pos == -1){
		if(valor == enteros[i]){
			pos = i;	
		}
		i++;
	}*/
	// Borra la posicion anterior y vuelve a mostrar el vector.
	if(pos != -1){
		enteros.erase(enteros.begin() + pos);
	}
	for(int i = 0; i < enteros.size(); i++){
		cout << enteros[i] << " ";
	}
	cout << endl;

	// Pedimos un ultimo valor y eliminamos del vector todas las veces
	// que aparece.

	// i i
	// 0 1 2 3 4 5 6 7
	// ---------------
	// 9 2 2 9 9 2 2 9
	
	// i i
	// 0 1 2 3 4 5 6
	// ---------------
	// 9 2 9 9 2 2 9


	for(int i = 0; i < enteros.size(); i++){
		if(valor == enteros[i]){
			enteros.erase(enteros.begin() + i);
			i--;
		}
	}

	// aqui podemos elegir si queremos incrementar o no el while
	// en una iteracion.
	int i = 0;
	while(i < enteros.size()){
		if(valor == enteros[i]){
			enteros.erase(enteros.begin() + i);
		}
		else{
			i++;
		}
	}
	
	// Muestra finalmente el estado del vector.
	for(int i = 0; i < enteros.size(); i++){
		cout << enteros[i] << " ";
	}
	cout << endl;
	
	return 0;
}
