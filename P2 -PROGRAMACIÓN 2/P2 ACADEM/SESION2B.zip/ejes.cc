#include <iostream>
#include <vector>
using namespace std;

int main(){	
	// 1. Cread un vector dinamico de enteros.
	vector<int> enteros;
	int valor;

	// 2. Meted diez valores enteros introducidos por el usuario.
	for(int i = 1; i <= 10; i++){
		cout << "introduce un valor: ";
		cin >> valor;
		enteros.push_back(valor);
	}

	// 3. imprimid el vector por pantalla.
	for(int i = 0; i < enteros.size(); i++){
		cout << enteros[i] << " ";
	}
	cout << endl;
	
	// 4. pedid un valor y mostrad las posiciones en las cuales apareces
	int buscado;
	cout << "Introduce el valor a buscar: ";
	cin >> buscado;
	for(int i = 0; i < enteros.size(); i++){
		if(enteros[i] == buscado){
			cout << "encontrado en la posicon " << i << endl;
		}
	}

	// 5. pedid un valor y mostrad la primera posicion en la cual
	// aparece, "no esta" si no esta.
	int pos;
	pos = -1;
	for(int i = 0; i < enteros.size() && pos == -1; i++){
		if(enteros[i] == buscado){
			pos = i;	
		}
	}
	if(pos == -1){
		cout << "no lo has encontraod" << endl;
	}
	else{
		cout << "Lo he encontrado en la posicion " << pos << endl;
	}

	// pasad el bucle anterior a while!
	int i;
	i = 0;
	pos = -1;
	while(i < enteros.size() && pos == -1){
		if(enteros[i] == buscado){
			pos = i;
		}
		i++;
	}
	if(pos == -1){
		cout << "no lo has encontraod" << endl;
	}
	else{
		cout << "Lo he encontrado en la posicion " << pos << endl;
	}
	
	// 6. elimina la posicion donde has encontrado el valor en el vector.
	if(pos != -1){
		enteros.erase(enteros.begin() + pos);
	}	
	cout << "despues de borrar el valor: ";
	for(int i = 0; i < enteros.size(); i++){
		cout << enteros[i] << " ";
	}
	cout << endl;


	// 7. elimina todas las ocurrencias (veces que aperece) el 
	// valor en el vector.
	cout << "Introduce el valor a borrar (voy a borrarlo todos): ";
	cin >> buscado;
/*
	buscado = 2	

	i	i	i
	0	1	2	3	4	5	6	7
	---------------------------------------------------------
	3	3	2	2	7	9	2	10
				🤔️

	i	i	i  =>   i
	0	1	2	4	5	6	7
	---------------------------------------------------------
	3	3	2	7	9	2	10
			🤔️

*/

/*	for(int i =  0; i < enteros.size(); i++){
		if(enteros[i] == buscado){
			enteros.erase(enteros.begin() + i);
			i--; // 🍌️💦️
		}
	}*/
	
	// ❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️
	i = 0;
	while(i < enteros.size()){
		if(enteros[i] == buscado){
			enteros.erase(enteros.begin() + i);
		}
		else{
			i++;
		}
	}
	// ❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️
	for(int valor : enteros){
		cout << valor << " ";
	}
	cout << endl;
	

	return 0;
}
