#include <string>
#include <iostream>
using namespace std;
/*
	Devuelve cierto si la longitud esta entre 4 y 10
	y todos los caracteres son letras minusculas.
*/
bool cmpName(string n){

}

/*
	Devuelve cierto si la cadena tiene dos partes
	una en la que todo son digitos y luego otra en
	la que todo son letras, cualquier parte puede estar
	vacia:
		123321asdfasfda
		afddsfasdf
		234324
		=> 132addfa12313
*/
bool twoFaces(string n){

}


/*
	Devuelve cierto si solo contiene digitos,
	es decir caracteres nuemricos

	31413241
	3214a2342 NO
*/
bool onlyDigits(string n){


}

// devuelve cierto si todos los caracteres de la cadena n
// aparecen en el conjunto de caracteres charset
//	validCharset("134aa", "1234556789abc") => true
//	validCharset("134aaz", "1234556789abc") => false
bool validCharset(string n, string charset){

}

int main(){

}




