#include <cstring>
#include <iostream>
using namespace std;


int main(){
	string cadena;

	cout << "Introduce una cadena: ";
	getline(cin, cadena);

	// contar y mostrad por pantalla la cantidad de veces
	// que aparece el caracter .
	int veces, i, tam;

	veces = 0;
	tam = cadena.length();
	for(i = 0; i < tam; i++){
		if(cadena[i] == '.'){
			veces++;
		}
	}
	cout << "El caracter . aparece " << veces << " veces. " << endl;

	
	cout << "Introduce otra cadena: ";
	getline(cin, cadena);
	
	// buscamos la cantidad de veces que aparece el caracter @ en
	// la cadena y en caso de que este solo una vez, 
	// separamos la cadena en dos trozos una con lo que hay delante
	// de la @ y otra conn lo que hay detras.
	// cadena = "hola@quetal" <la introduce el usuario>
	// 	pizq ="hola"
	// 	pder = "quetal"
	tam = cadena.length();	
	veces = 0;
	for(i = 0; i < tam;i++){
		if(cadena[i] == '@'){
			veces++;
		}
	}
	if(veces == 1){
		string pizq, pder;
		
		pizq = "";
		i = 0;
		while(cadena[i] != '@'){
			pizq = pizq + cadena[i];
			cout << pizq << endl;
			i++;
		}

		pder = "";
		i = i + 1;
		while(i < tam){
			pder = pder + cadena[i];
			cout << pder << endl;
			i++;
		}
/*		for(i = i + 1; i < tam; i++){
			pder = pder + cadena[i];
			cout << pder << endl;
		}*/
	}
	// pedir una cadena y mostrad por pantalla
	// ok si todos los caracteres de la cadena son letras
	// no ok si hay alguno que no es una letra
	cout << "Introduce una palabra: ";
	getline(cin, cadena);
	bool todosLetras = true;
	tam = cadena.length();
	for(i = 0; i < tam && todosLetras == true; i++){
		// si encuentro alguno qu eno es letra...
		//if(cadena[i] < 'a' || cadena[i] > 'z'){}
		if(isalpha(cadena[i]) == 0){
			todosLetras = false;
		}
	}
	if(todosLetras == false){
		cout << "no ok" << endl;
	}
	else{
		cout << "ok" << endl;
	}









}

