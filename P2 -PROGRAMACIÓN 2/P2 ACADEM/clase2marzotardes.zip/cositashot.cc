#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int main(){
	ofstream fich;
	vector<string> sal = {"ba", "bo", "be", "bi", "bu"};

	fich.open("lineas.txt");
	if(fich.is_open()){
		for(string s : sal){
			fich << s << endl;
			cout << "Escribiendo... " << s << endl;
		} 
		fich.close();
	}

	return 0;
}
