#include <iostream>

using namespace std;

const int KNAME=40;
const int KMAXOBSTACLES=20;

enum Error{
    ERR_OPTION,
    ERR_DIFFICULTY,
    ERR_LEVEL,
    ERR_COORDINATE,
    ERR_OBSTACLES,
    ERR_ID,
    ERR_INSTRUCTION
};

// Registro para las coordenadas
struct Coordinate{
    int row;
    int column;
};

// Registro para el jugador
struct Player{
    char name[KNAME];
    int difficulty;
    int score;
    int wins;
    int losses;
};

// Registro para el nivel
struct Level{
    int id;
    int size;
    int numObstacles;
    Coordinate obstacles[KMAXOBSTACLES];
    Coordinate start;
    Coordinate finish;
};

// Función que muestra los mensajes de error
void error(Error e){
    switch(e){
        case ERR_OPTION: cout << "ERROR: wrong option" << endl;
            break;
        case ERR_DIFFICULTY: cout << "ERROR: wrong difficulty" << endl;
            break;
        case ERR_LEVEL: cout << "ERROR: cannot create level" << endl;
            break;
        case ERR_COORDINATE: cout << "ERROR: wrong coordinate" << endl;
            break;
        case ERR_OBSTACLES: cout << "ERROR: wrong number of obstacles" << endl;
            break;
        case ERR_ID: cout << "ERROR: wrong id" << endl;
            break;
        case ERR_INSTRUCTION: cout << "ERROR: wrong instruction" << endl;
            break;
    }
}

// Función que muestra el menú de opciones
void showMenu(){
    cout << "[Options]" << endl
        << "1- Create level" << endl
        << "2- Delete level" << endl
        << "3- Show levels" << endl
        << "4- Play" << endl
        << "5- Report" << endl
        << "q- Quit" << endl
        << "Option: ";
}
#include <vector>
// si no lo modfico => const &
// si lo modifco => &
void createLevel(vector<Level> &levels, const Player &p, int &nextId){
	Level newLevel;
	if(levels.size() == KMAXLEVELS){
		error(ERR_LEVEL);
	}
	else{
		// leer newLevel
		newLevel.id = nextId;
		nextId++;
		// TODO
		// newLevel.start.row = 
		// newLevel.start.column = 
		// newLevel.finish.row = 
		// newLevel.finish.column = 
		// switch o if else para determinar el size en funcion
		// del p.difficulty		
		// newLevel.size = 
		// LO DE LOS OBSTACULOS LO HAGO YO!!
		levels.push_back(newLevel);
	}
	
}

void createLevelVintage(Level levels[], int &numLevels, int d, int &nextId){
	Level newLevel;
	if(numLevels == KMAXLEVELS){
		error(ERR_LEVEL);
	}
	else{
		// le pedimos al usuario la variable newLevel
		newLevel.id = nextId;
		nextId++;
		// rellenamos las cositas TODO
		levels[numLevels] = newLevel;
		numLevels++;	
	}
}

void deleteLevels(vector<Level> &levels){
	int id;
	int pos;
	
	cout << "Id: ";
	cin >> id;
	cin.get();
			
	// busqueda secuencial
	pos = -1;
	for(int i = 0; i < levels.size() && pos == -1; i++){
		if(levels[i].id == id){
			pos = i;
		}
	}
	if(pos == -1){
		error(ERR_ID);
	}
	else{
		// pregunta hasta la saciedad....
		
		levels.erase(levels.begin() + pos);
	}

}



// Función principal (tendrás que añadirle más código tuyo)
int main(){
    char option;
	Player player;
	/*Level levels[10];
	int numLevels = 0;*/
	vector<Level> levels; 
	int nextId = 1;  

	// METED ESTO DENTRO DE UNA FUNCION!!!
	// initPlayer(player);	 => void initPlayer(Player &player){}
	// player = newPlayer(); => Player newPlayer(){Player n; return n;}

	cout << "Name: ";
	cin.getline(player.name, KNAME);

	// TODO pedid esto mientras no este bien y sacar el error.
	cout << "Difficulty: ";
	cin >> player.difficulty;
	cin.get();
	
	player.score = 0;
	player.wins = 0;
	player.losses = 0;

    do{
        showMenu();
        cin >> option;
        cin.get(); // Para evitar que el salto de línea se quede en el buffer de teclado y luego pueda dar problemas si usas "getline"
        
        switch(option){
            case '1': // Llamar a la función para crear un nuevo nivel
				createLevel(levels, player, nextId);
				// createLevelVintage(levels, numLevels, player.difficutly, nextId);
                break;
            case '2': // Llamar a la función para borrar un nivel existente
				deleteLevel(levels);
                break;
            case '3': // Llamar a la función para mostrar los niveles creados
                break;
            case '4': // Llamar a la función para jugar
                break;
            case '5': // Llamar a la función para mostrar información del jugador
                break;
            case 'q': break;
            default: error(ERR_OPTION); // Muestra "ERROR: wrong option"
        }
    }while(option!='q');
}
