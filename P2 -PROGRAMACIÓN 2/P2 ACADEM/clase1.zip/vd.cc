#include <iostream>
#include <vector>
using namespace std;

namespace chat{
	void f(){
		cout << "locura de chat" << endl;
	}
}

namespace game{
	void f(){
		cout << "locura de game" << endl;
	}
}

int main(){
	chat::f();
	game::f();

	vector<int> enteros;
	vector<string> cadenas;
	vector<bool> activados;

	cout << enteros.size() << endl;
	cout << cadenas.size() << endl;
	cout << activados.size() << endl;
	
	// enteros[0] = 12; // error
	enteros.push_back(23); // añade una posicion al final del vector
	// y COPIA el argumento en esa posicion.
	enteros.push_back(35);
	enteros.push_back(90);

	cout << enteros.size() << endl;	
	enteros[0]++;
	enteros[1] = enteros[0] + 10;
	
	for(int i = 0; i < enteros.size(); i++){
		cout << i << " => " << enteros[i] << endl;
	}
	cout << endl;

	enteros.push_back(69);
	for(int i = 0; i < enteros.size(); i++){
		cout << i << " => " << enteros[i] << endl;
	}
	cout << endl;

	enteros.insert(enteros.begin(), 12);
	for(int i = 0; i < enteros.size(); i++){
		cout << i << " => " << enteros[i] << endl;
	}
	cout << endl;
	
	enteros.insert(enteros.begin() + 1, 90);
	for(int i = 0; i < enteros.size(); i++){
		cout << i << " => " << enteros[i] << endl;
	}
	cout << endl;
	
	enteros.erase(enteros.begin());
	for(int i = 0; i < enteros.size(); i++){
		cout << i << " => " << enteros[i] << endl;
	}
	cout << endl;
	return 0;
}

