#include <iostream>
#include <vector>
using namespace std;

class Hora{
	private:
		int horas, minutos;
	public:
		Hora(){
			horas = 0;
			minutos = 0;
		}
		// [23-0:59-0]
		// si alguno de los valores esta fuera de rango
		// se inicializara a 0
		Hora(int vh, int vm){
			if(vh < 0 || vh > 23 || vm < 0 || vm > 59){
				horas = 0;
				minutos = 0;
			}
			else{
				horas = vh;
				minutos = vm;
			}
		}
		// los metodos que no modifican (solo consultan)
		// el objeto que lo invoca son const.
		int getHoras() const{
			return horas;
		}
		int getMinutos() const{
			return minutos;		
		}
		void setHoras(int vh){
			if(vh > 0){
				horas = vh;
			}
		}
		void setMinutos(int vm){
			if(vm > 0){
				minutos = vm;
			}
		}
		int getTotalMinutos() const{
			// horas y minutos
			return horas * 60 + minutos;
		}
		// el metodo es const por que el objeto que lo invoca
		// no se va a modificar
		// y el const & es porque el parametro no se podra modificar.
		// Hora h1(12, 32);
		// Hora h2(12, 45);
		// cout << h1.resta(h2);
		// cout << h2.resta(h1);
		int resta(const Hora &de) const{
			// ¿Que bariables tengo aqui y de donde bienen?
			// de.horas de.minutos (parametro)
			// horas minutos (objeto que invoca el metodo)
			int total1, total2;
			total1 = horas * 60 + minutos;
			total2 = de.horas * 60 + de.minutos;
			return total1 - total2;
		}
		bool iguales(const Hora &de) const{
			return de.horas == horas && de.minutos == minutos;
		}
		// incrementa la hora en una hora, devuelve cierto si se ha cambiado
		// de dia.
		// Hora h1(12, 23);
		// h1.incHora();
		// h1.incHora();
		// Hora h2(34, 12);
		// h2.incHora();
		bool incHora(){
			bool pasa = false;
			// horas y minutos
			horas++;
			if(horas >= 24){
				horas = 0;
				pasa = true;
			}
			return pasa;
		}
		// incrementa los minutos en uno y  devuelve cierto si cambia de dia
		bool incMinutos(){
			bool pasa = false;
			minutos++;
			if(minutos == 60){
				minutos = 0;
				horas++;
				if(horas == 24){
					pasa = true;
					horas = 0;
				}	
			}
			return pasa;
		}
		void imprimir(){
			cout << horas << ":" << minutos;
		}
		// si el valor es positivo, se incrementa la hora en los minutos
		// pasado como parametros, devuelve el numero de veces que se ha 
		// cambiado de dia
		int incMinutos(int minutos){
			int dias = 0;
			for(int i = 1; i <= minutos; i++){
				if(incMinutos()){
					dias++;
				}
			}
			return dias;
		}
		// decrementa la hora en 1 si cambio de dia
		// devuelve cierto
		bool decHoras(){
			bool cambio;
			horas--;
			if(horas == -1){
				horas = 23;
				cambio = true;
			}
			else{
				cambio = false;
			}
			return cambio;
		}
		// decrementa el minutos 1 si cambio de dia
		// devuelve cierto
		bool decMinutos(){
			bool cambio;
			minutos--;
			if(minutos == -1){
				minutos = 59;
				cambio = decHoras();
			}
			return cambio;
		}
		

};
int main(){
	Hora uno(12, 23);
	uno.incMinutos();
	uno.imprimir();
	cout << endl;

	Hora h1(12, 32);
	Hora h2(12, 45);
	cout << h1.resta(h2) << endl;
	cout << h2.resta(h1) << endl;


	Hora entrada1(12, 32); 	// vh = 12 vm = 32
				// horas = 12
				// minutos = 32

	Hora entrada2(-12, 32);
				// vh = -12 vm = 32
				// horas = 0
				// minutos = 0

	cout << entrada1.getHoras() << ":" << entrada1.getMinutos() << endl;
	// 12 32
	cout << entrada2.getHoras() << ":" << entrada2.getMinutos() << endl;	
	// 0 0

	entrada1.setHoras(-23);	// vh = -23
	entrada2.setHoras(12);  // vh = 12
				// horas = 12


	


	return 0;
}
