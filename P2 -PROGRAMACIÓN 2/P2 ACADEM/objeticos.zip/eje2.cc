#include <iostream>
using namespace std;

class Coord{
	public:
		int x, y;

	// Metodos constructores:
	//	- Su nombre coincide con el nombre de la clase que los contiene
	//	- No devuelve nada ni siquiera void.
	//	- Podemos tener varios constructores (sobrecarga) con el mismo
	// 	nombre siempre que difieran en el tipo/numero u orden de sus
	// 	argumentos.
	//	- Los constructores sirven para inicializar los nuevos objetos.
	//	 constructor por defecto.
	// 	- Reciben de forma implicita el objeto que se esta inicializando.
		Coord(){
			x = 0;
			y = 0;
		}
		// constructores pararametrizados.
		Coord(int vx, int vy){
			x = vx;
			y = vy;
		}	

};

int main(){
	Coord c2; // c++ invoca de forma implicita al cpd.
	Coord c1(12, 32);	// vx = 12, vy = 32
				// x = 12
				// y = 32

	Coord c3(35, 90);	// vx = 35
				// vy = 90
				// x = 35
				// y = 90
	Coord c4; // c++ invoca de forma implicita al cpd.

	Coord c5(c1.x, c3.y);

	cout << c1.x << ", " << c1.y << endl;
	cout << c2.x << ", " << c2.y << endl;
	cout << c3.x << ", " << c3.y << endl;
	cout << c4.x << ", " << c4.y << endl;
	
	return 0;
}




