#include <iostream>
using namespace std;

class Natural{
	private:
		int valor;

	public:
		// :)
		Natural(){
			valor = 0;
		}
		Natural(int v){
			if(v < 0){
				valor = 0;
			}
			else{
				valor = v;			
			}
		}	
		// otros metodos de instancia.
		// RECIBEN DE FORMA IMPLICITA EL OBJETO QU EINVOCA EL METODO.
		int getValor(){
			return valor;
		}
		void setValor(int v){
			if(v > 0){
				valor = v;
			}
		}
};
int main(){
	Natural n1(12);		// n1.valor = 12
	Natural n2(34); 	// n2.valor = 34
	Natural n3(-34); 	// n3.valor = 0
	Natural n4(-23);	// n4.valor = 0
//	cout << n1.valor << endl;
//	cout << n2.valor << endl;
//	cout << n3.valor << endl;
//	cout << n4.valor << endl;
	cout << n1.getValor() << endl; //  return n1.valor;
	cout << n2.getValor() << endl; //  return n2.valor;


	// ENCAPSULACION: PROTEGEMOS A LOS DATOS DE MODIFICACIONES INCORRECTAS.
	n1.setValor(69);	// v = 69	n1.valor = 69
	n2.setValor(-132);	// v = -132
	cout << n1.getValor() << endl; // 69
	cout << n2.getValor() << endl; // 34

//	n1.valor = -123;
//	cout << n1.valor << endl;
	
	return 0;
}
